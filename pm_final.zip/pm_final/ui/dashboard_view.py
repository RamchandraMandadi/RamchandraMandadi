"""
dashboard_view.py  — Dashboard tab
Matches the Portfolio Manager HTML design:
  • KPI stat cards (top row)
  • RAG stacked bar chart (left)
  • Projects At Risk panel (right)
  • Portfolio Health Snapshot table (bottom)
"""

import tkinter as tk
from tkinter import ttk

# ── Palette ────────────────────────────────────────────────────────────────────
C = {
    'bg':       '#f0f2f7',
    'surface':  '#ffffff',
    'border':   '#dde1ed',
    'ink':      '#000000',
    'ink2':     '#000000',
    't2':       '#000000',
    'accent':   '#1a3fc4',
    'R':        '#e53935', 'R_bg': '#fdecea', 'R_bdr': '#f5c6c4',
    'A':        '#f59e0b', 'A_bg': '#fffbeb', 'A_bdr': '#fde68a',
    'G':        '#16a34a', 'G_bg': '#f0fdf4', 'G_bdr': '#bbf7d0',
}
RAG_ASPECTS = ['Scope','Schedule','Budget','Changes','Issues',
               'Risks','Dependencies','Resourcing','Technical','Change Mgmt']


def rag_color(s):
    return {'R': C['R'], 'A': C['A'], 'G': C['G']}.get(s, C['G'])

def rag_bg(s):
    return {'R': C['R_bg'], 'A': C['A_bg'], 'G': C['G_bg']}.get(s, C['G_bg'])


class DashboardView(tk.Frame):

    def __init__(self, parent, svc):
        super().__init__(parent, bg=C['bg'])
        self.svc = svc
        self._build()

    def _build(self):
        # scrollable canvas
        canvas = tk.Canvas(self, bg=C['bg'], highlightthickness=0)
        vsb = ttk.Scrollbar(self, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner = tk.Frame(canvas, bg=C['bg'])
        win_id = canvas.create_window((0, 0), window=inner, anchor='nw')

        def _resize(e):
            canvas.configure(scrollregion=canvas.bbox('all'))
            canvas.itemconfig(win_id, width=canvas.winfo_width())
        inner.bind('<Configure>', _resize)
        canvas.bind('<Configure>', lambda e: canvas.itemconfig(win_id, width=e.width))
        canvas.bind_all('<MouseWheel>',
            lambda e: canvas.yview_scroll(int(-1*(e.delta/60)), 'units'))

        pad = tk.Frame(inner, bg=C['bg'], padx=22, pady=20)
        pad.pack(fill='both', expand=True)

        kpis   = self.svc.get_kpis()
        rag_sm = self.svc.get_rag_summary()
        risks  = self.svc.get_projects_at_risk()
        health = self.svc.get_health_table()

        self._kpi_row(pad, kpis)
        self._mid_row(pad, rag_sm, risks)
        self._health_table(pad, health)

    # ── KPI cards ─────────────────────────────────────────────────────────────
    def _kpi_row(self, parent, kpis):
        frame = tk.Frame(parent, bg=C['bg'])
        frame.pack(fill='x', pady=(0, 18))

        spent_pct = (kpis['spent'] / kpis['budget'] * 100) if kpis['budget'] else 0

        cards = [
            ('Total Projects',   str(kpis['total']),       'all projects',         C['accent'], None),
            ('🔴 At Risk',        str(kpis['at_risk']),     'red RAG',              C['R'],      None),
            ('🟡 Amber',          str(kpis['amber']),       'needs attention',      C['A'],      None),
            ('🟢 Green',          str(kpis['green']),       'on track',             C['G'],      None),
            ('Budget Used',      f"{spent_pct:.0f}%",      f"${kpis['spent']:,.0f} / ${kpis['budget']:,.0f}", '#7c3aed', None),
            ('Avg Progress',     f"{kpis['avg_progress']}%",'across all projects',  C['accent'], None),
        ]
        for col, (label, value, sub, color, _) in enumerate(cards):
            frame.columnconfigure(col, weight=1)
            self._kpi_card(frame, label, value, sub, color, col)

    def _kpi_card(self, parent, label, value, sub, color, col):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'],
                        highlightthickness=1)
        card.grid(row=0, column=col, sticky='ew', padx=5, pady=2, ipady=12)

        # top accent bar
        accent = tk.Frame(card, bg=color, height=3)
        accent.pack(fill='x')

        tk.Label(card, text=label, font=('Segoe UI', 9),
                 bg=C['surface'], fg=C['t2']).pack(pady=(10,2))
        tk.Label(card, text=value, font=('Segoe UI', 22, 'bold'),
                 bg=C['surface'], fg=color).pack()
        tk.Label(card, text=sub, font=('Segoe UI', 8),
                 bg=C['surface'], fg=C['t2']).pack(pady=(2,10))

    # ── Middle row: RAG chart + At Risk ───────────────────────────────────────
    def _mid_row(self, parent, rag_sm, risks):
        row = tk.Frame(parent, bg=C['bg'])
        row.pack(fill='x', pady=(0, 18))
        row.columnconfigure(0, weight=3)
        row.columnconfigure(1, weight=2)

        self._rag_chart(row, rag_sm)
        self._at_risk_panel(row, risks)

    # ── RAG stacked bar chart ─────────────────────────────────────────────────
    def _rag_chart(self, parent, rag_sm):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.grid(row=0, column=0, sticky='nsew', padx=(0,8))

        tk.Label(card, text='RAG Status by Aspect',
                 font=('Segoe UI', 11, 'bold'), bg=C['surface'],
                 fg=C['ink'], anchor='w').pack(fill='x', padx=16, pady=(14,8))

        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        canvas_frame = tk.Frame(card, bg=C['surface'])
        canvas_frame.pack(fill='both', expand=True, padx=16, pady=14)

        BAR_H = 26
        GAP   = 8
        LBL_W = 110

        # Build project-level detail for tooltip:
        # {asp: {status: [proj_name, ...]}}
        rag_raw   = self.svc.get_rag()
        projects  = {str(p['ProjectID']): p.get('ProjectName','')
                     for p in self.svc.get_projects()}
        asp_detail = {}   # asp → {'R':[names],'A':[names],'G':[names]}
        for asp in RAG_ASPECTS:
            asp_detail[asp] = {'R':[], 'A':[], 'G':[]}
            for pid, p_rag in rag_raw.items():
                s = p_rag.get(asp, {}).get('status', 'G')
                name = projects.get(pid, pid)
                asp_detail[asp][s].append(name)

        TOTAL   = max(v for asp in rag_sm for v in rag_sm[asp].values()
                      if isinstance(v, int)) or 4
        chart_h = len(RAG_ASPECTS) * (BAR_H + GAP) + 10

        c = tk.Canvas(canvas_frame, bg=C['surface'],
                      height=chart_h, highlightthickness=0,
                      cursor='crosshair')
        c.pack(fill='x', expand=True)

        # Tooltip label (hidden until hover)
        tip = tk.Label(card, text='', font=('Segoe UI', 8),
                       bg='#000000', fg='white',
                       padx=8, pady=4, relief='flat',
                       justify='left', wraplength=300)

        # Store hit-boxes: [(x0,y0,x1,y1, asp, status, names)]
        _hits = []

        def draw_bars(event=None):
            c.delete('all')
            _hits.clear()
            W     = c.winfo_width() or 500
            bar_w = W - LBL_W - 20

            for i, asp in enumerate(RAG_ASPECTS):
                y      = i * (BAR_H + GAP) + 5
                counts = rag_sm.get(asp, {'R':0,'A':0,'G':0})
                total  = counts['R'] + counts['A'] + counts['G'] or 1

                c.create_text(LBL_W - 8, y + BAR_H//2,
                              text=asp, anchor='e',
                              font=('Segoe UI', 9), fill=C['ink2'])
                c.create_rectangle(LBL_W, y, LBL_W + bar_w, y + BAR_H,
                                   fill='#e5e7eb', outline='')

                x = LBL_W
                for status, clr in [('R', C['R']), ('A', C['A']), ('G', C['G'])]:
                    n   = counts[status]
                    seg = int(bar_w * n / total)
                    if seg > 0:
                        c.create_rectangle(x, y, x + seg, y + BAR_H,
                                           fill=clr, outline='')
                        if seg > 22:
                            c.create_text(x + seg//2, y + BAR_H//2,
                                          text=str(n),
                                          font=('Segoe UI', 8, 'bold'),
                                          fill='white')
                        names = asp_detail.get(asp, {}).get(status, [])
                        _hits.append((x, y, x + seg, y + BAR_H,
                                      asp, status, names))
                        x += seg

        def _status_label(s):
            return {'R':'Red','A':'Amber','G':'Green'}.get(s, s)

        def on_motion(event):
            mx, my = event.x, event.y
            for (x0,y0,x1,y1,asp,status,names) in _hits:
                if x0 <= mx <= x1 and y0 <= my <= y1:
                    projects_str = '\n'.join(f'  • {n}' for n in names) if names else '  —'
                    tip.config(
                        text=f'{asp}  ›  {_status_label(status)}\n{projects_str}')
                    # position tooltip below cursor inside the card
                    tip.place(x=event.x_root - card.winfo_rootx() + 12,
                              y=event.y_root - card.winfo_rooty() + 12)
                    tip.lift()
                    return
            tip.place_forget()

        def on_leave(event):
            tip.place_forget()

        c.bind('<Configure>', draw_bars)
        c.bind('<Motion>',   on_motion)
        c.bind('<Leave>',    on_leave)
        card.after(100, draw_bars)

        # legend
        leg = tk.Frame(card, bg=C['surface'])
        leg.pack(pady=(0,12))
        for label, color in [('Red', C['R']), ('Amber', C['A']), ('Green', C['G'])]:
            dot = tk.Frame(leg, bg=color, width=12, height=12)
            dot.pack(side='left', padx=(8,3))
            tk.Label(leg, text=label, font=('Segoe UI', 8),
                     bg=C['surface'], fg=C['t2']).pack(side='left', padx=(0,8))
        tk.Label(leg, text='  Hover over a bar segment to see project names',
                 font=('Segoe UI', 7), bg=C['surface'],
                 fg=C['t2']).pack(side='left', padx=8)

    # ── At Risk panel ─────────────────────────────────────────────────────────
    def _at_risk_panel(self, parent, risks):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.grid(row=0, column=1, sticky='nsew')

        tk.Label(card, text='Projects at Risk',
                 font=('Segoe UI', 11, 'bold'), bg=C['surface'],
                 fg=C['ink'], anchor='w').pack(fill='x', padx=16, pady=(14,8))
        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        scroll_frame = tk.Frame(card, bg=C['surface'])
        scroll_frame.pack(fill='both', expand=True, padx=12, pady=10)

        if not risks:
            tk.Label(scroll_frame, text='✅  All projects are on track',
                     font=('Segoe UI', 10), bg=C['surface'],
                     fg=C['G']).pack(pady=20)
            return

        for r in risks:
            item = tk.Frame(scroll_frame, bg=C['R_bg'],
                            highlightbackground=C['R_bdr'],
                            highlightthickness=1)
            item.pack(fill='x', pady=4, ipady=8)

            top = tk.Frame(item, bg=C['R_bg'])
            top.pack(fill='x', padx=10, pady=(4,2))

            badge = tk.Label(top, text='R', width=2,
                             bg=C['R'], fg='white',
                             font=('Segoe UI', 10, 'bold'))
            badge.pack(side='left', padx=(0,8))

            tk.Label(top, text=r['name'],
                     font=('Segoe UI', 10, 'bold'),
                     bg=C['R_bg'], fg=C['ink']).pack(side='left')

            red_text = 'Red: ' + ', '.join(r['reds'])
            tk.Label(item, text=red_text, font=('Segoe UI', 8),
                     bg=C['R_bg'], fg=C['R'],
                     anchor='w').pack(fill='x', padx=10)
            tk.Label(item, text=r['manager'], font=('Segoe UI', 8),
                     bg=C['R_bg'], fg=C['t2'],
                     anchor='w').pack(fill='x', padx=10)

    # ── Portfolio Health Snapshot table ───────────────────────────────────────
    def _health_table(self, parent, health):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.pack(fill='both', expand=True)

        tk.Label(card, text='Portfolio Health Snapshot',
                 font=('Segoe UI', 12, 'bold'),
                 bg=C['surface'], fg=C['ink'],
                 anchor='w').pack(fill='x', padx=16, pady=(14,8))
        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        # canvas-based table for colored R/A/G badges
        tbl_frame = tk.Frame(card, bg=C['surface'])
        tbl_frame.pack(fill='both', expand=True, padx=8, pady=8)

        cols = ['Project', 'Manager', 'Overall'] + RAG_ASPECTS
        col_widths = [170, 120, 70] + [65]*len(RAG_ASPECTS)

        # Header row
        hdr = tk.Frame(tbl_frame, bg=C['ink'])
        hdr.pack(fill='x')
        for i, (col, w) in enumerate(zip(cols, col_widths)):
            tk.Label(hdr, text=col.upper(), width=0, font=('Segoe UI', 8, 'bold'),
                     bg=C['ink'], fg='white', anchor='w',
                     padx=6, pady=8).pack(side='left', padx=1)
            # spacer to simulate fixed widths
            tk.Frame(hdr, bg=C['ink'], width=w).pack(side='left')

        # Rebuild proper grid-based header
        hdr.destroy()
        hdr = tk.Frame(tbl_frame, bg=C['ink'])
        hdr.pack(fill='x')
        for i, (col, w) in enumerate(zip(cols, col_widths)):
            lbl = tk.Label(hdr, text=col.upper(),
                           font=('Segoe UI', 8, 'bold'),
                           bg=C['ink'], fg='white',
                           anchor='w', padx=6, pady=8,
                           width=w//7)
            lbl.grid(row=0, column=i, sticky='ew')
        for i in range(len(cols)):
            hdr.columnconfigure(i, minsize=col_widths[i])

        # Data rows
        for ri, row in enumerate(health):
            bg = C['surface'] if ri % 2 == 0 else '#f7f8fc'
            r_frame = tk.Frame(tbl_frame, bg=bg)
            r_frame.pack(fill='x')

            # Project name
            tk.Label(r_frame, text=row['name'],
                     font=('Segoe UI', 9, 'bold'),
                     bg=bg, fg=C['ink'],
                     anchor='w', padx=6, pady=10,
                     width=col_widths[0]//7).grid(row=0, column=0, sticky='ew')
            # Manager
            tk.Label(r_frame, text=row['manager'],
                     font=('Segoe UI', 9),
                     bg=bg, fg=C['t2'],
                     anchor='w', padx=6,
                     width=col_widths[1]//7).grid(row=0, column=1, sticky='ew')

            # RAG badges: Overall + all aspects
            badge_cols = [row['overall']] + [row.get(a, 'G') for a in RAG_ASPECTS]
            for ci, status in enumerate(badge_cols):
                cell = tk.Frame(r_frame, bg=bg)
                cell.grid(row=0, column=ci+2, sticky='ew', padx=2)
                r_frame.columnconfigure(ci+2, minsize=col_widths[ci+2])

                badge = tk.Label(cell, text=status, width=2,
                                 bg=rag_color(status), fg='white',
                                 font=('Segoe UI', 8, 'bold'),
                                 pady=3)
                badge.pack(pady=4)

            # separator
            tk.Frame(tbl_frame, bg=C['border'], height=1).pack(fill='x')

    def refresh(self):
        for w in self.winfo_children():
            w.destroy()
        self._build()
