"""
dynamic_table.py  —  MS-Project / Excel look-and-feel task table
─────────────────────────────────────────────────────────────────
Changes vs previous version
  • Drag-drop bug fixed: when a subtask is moved to a new parent the old
    ParentTaskID is replaced with the new one AND ProjectID is synced to
    the target project — the "invalid parent id" error is gone.
  • Full MS-Project visual theme:
      – Light Excel grid (white + #F2F2F2 alternating rows, blue header)
      – Inline % progress bar drawn inside the Progress column
      – Status rendered as a coloured pill/chip
      – Row numbers in the #0 tree column
      – Bold parent rows, indented children (kept from before)
      – Gridline separators via tag background cycling
      – Sticky frozen header
  • "Re-parent" context-menu on right-click (replaces need for separate
    toolbar button — keeps toolbar unchanged).
  • All existing functionality preserved.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import math

from ui.toolbar import CommandToolbar
from ui.dynamic_form import DynamicForm
from core.task_hierarchy import TaskHierarchyBuilder
from core.hierarchy_validator import HierarchyValidator


# ─────────────────────────────────────────────────────────────────────────────
# THEME CONSTANTS  (MS-Project / Excel palette)
# ─────────────────────────────────────────────────────────────────────────────
_COL_HEADER_BG   = "#1F4E79"   # dark blue  – column headings
_COL_HEADER_FG   = "#FFFFFF"
_ROW_ODD         = "#FFFFFF"
_ROW_EVEN        = "#F2F7FF"   # very light blue tint
_ROW_SELECTED    = "#D0E4F7"
_PROJECT_HDR_BG  = "#2B5F8E"
_PROJECT_HDR_FG  = "#FFFFFF"
_GRID_LINE       = "#C8D8E8"
_PARENT_BG       = "#E8F0FB"
_FONT_BODY       = ("Calibri", 10)
_FONT_BOLD       = ("Calibri", 10, "bold")
_FONT_HEADER     = ("Calibri", 10, "bold")

# Progress bar colours
_PROG_BG         = "#D9E1EA"
_PROG_FILL_OK    = "#217346"   # green  (< 100 %)
_PROG_FILL_DONE  = "#1F4E79"   # blue   (= 100 %)


class DynamicTable(ttk.Frame):

    def __init__(self, parent, data_service, sheet_name):
        super().__init__(parent)

        self.data_service = data_service
        self.sheet_name   = sheet_name
        self.tree         = None

        # drag-and-drop state
        self._drag_source_item = None
        self._drag_tooltip     = None

        # row-number counter (reset each load)
        self._row_counter = 0

        self._apply_theme()
        self.build_table()

    # ══════════════════════════════════════════════════════════════════════════
    # THEME
    # ══════════════════════════════════════════════════════════════════════════
    def _apply_theme(self):
        style = ttk.Style()

        style.configure(
            "Excel.Treeview",
            background=_ROW_ODD,
            fieldbackground=_ROW_ODD,
            foreground="#000000",
            font=_FONT_BODY,
            rowheight=35,
            borderwidth=0,
        )
        style.map(
            "Excel.Treeview",
            background=[("selected", _ROW_SELECTED)],
            foreground=[("selected", "#000000")],
        )

        style.configure(
            "Excel.Treeview.Heading",
            background=_COL_HEADER_BG,
            foreground=_COL_HEADER_FG,
            font=_FONT_HEADER,
            relief="flat",
            padding=(4, 4),
        )
        style.map(
            "Excel.Treeview.Heading",
            background=[("active", "#2E6EA6")],
        )

        style.configure("Excel.Vertical.TScrollbar",
                        background="#C0C0C0", troughcolor="#F0F0F0", width=12)
        style.configure("Excel.Horizontal.TScrollbar",
                        background="#C0C0C0", troughcolor="#F0F0F0", width=12)

    # ══════════════════════════════════════════════════════════════════════════
    # CLEAN DATA
    # ══════════════════════════════════════════════════════════════════════════
    def clean_data(self, data):
        for k, v in data.items():
            if v is None:
                continue
            if isinstance(v, float) and math.isnan(v):
                data[k] = None
                continue
            if str(v).strip().lower() in ["", "nan", "none"]:
                data[k] = None

        if "Progress" in data:
            try:
                val = float(str(data["Progress"]).strip().rstrip("%"))
                data["Progress"] = max(0.0, min(100.0, val))
            except Exception:
                data["Progress"] = 0.0

        return data

    # ══════════════════════════════════════════════════════════════════════════
    # BUILD TABLE
    # ══════════════════════════════════════════════════════════════════════════
    def build_table(self):
        toolbar = CommandToolbar(
            self,
            self.add_record,
            self.add_subtask,
            self.edit_record,
            self.delete_record,
            self.refresh,
            self.recalculate_all_projects,
        )
        toolbar.pack(fill="x")

        self._excel_columns   = self.data_service.get_columns(self.sheet_name)
        self._display_columns = list(self._excel_columns)

        # outer border gives "Excel border" look
        border_frame = tk.Frame(self, bg=_GRID_LINE, bd=1, relief="sunken")
        border_frame.pack(fill="both", expand=True, padx=2, pady=2)

        tree_frame = tk.Frame(border_frame, bg=_ROW_ODD)
        tree_frame.pack(fill="both", expand=True)

        # ── Treeview ─────────────────────────────────────────────────────────
        if self.sheet_name.lower() == "tasks":
            self.tree = ttk.Treeview(
                tree_frame,
                columns=self._display_columns,
                show="tree headings",
                style="Excel.Treeview",
                selectmode="browse",
            )
            self.tree.heading("#0", text="  #  Task Hierarchy", anchor="w")
            self.tree.column("#0", width=220, minwidth=140, stretch=False)

            self.tree.bind("<MouseWheel>",     self.on_mouse_wheel)
            self.tree.bind("<Enter>",          lambda e: self.tree.focus_set())
            self.tree.bind("<ButtonPress-1>",  self._on_drag_start)
            self.tree.bind("<B1-Motion>",      self._on_drag_motion)
            self.tree.bind("<ButtonRelease-1>",self._on_drag_release)
            self.tree.bind("<Button-3>",       self._show_context_menu)

        else:
            self.tree = ttk.Treeview(
                tree_frame,
                columns=self._display_columns,
                show="headings",
                style="Excel.Treeview",
                selectmode="browse",
            )

        # ── Row tags ─────────────────────────────────────────────────────────
        self.tree.tag_configure("odd",  background=_ROW_ODD)
        self.tree.tag_configure("even", background=_ROW_EVEN)
        self.tree.tag_configure(
            "project_header",
            background=_PROJECT_HDR_BG,
            foreground=_PROJECT_HDR_FG,
            font=_FONT_BOLD,
        )
        self.tree.tag_configure(
            "parent",
            background=_PARENT_BG,
            font=_FONT_BOLD,
        )
        self.tree.tag_configure("drag_target", background="#FFF2CC")
        self.tree.tag_configure("green", background="#C6EFCE", foreground="#276221")
        self.tree.tag_configure("amber", background="#FFEB9C", foreground="#9C5700")
        self.tree.tag_configure("red",   background="#FFC7CE", foreground="#9C0006")

        # ── Column widths & sortable headings ────────────────────────────────
        COL_WIDTHS = {
            "TaskID":       55,
            "ProjectID":    65,
            "ProjectName": 130,
            "TaskName":    170,
            "ParentTaskID": 85,
            "AssignedTo":  100,
            "StartDate":    95,
            "EndDate":      95,
            "Status":      115,
            "Progress":     90,
        }
        for col in self._display_columns:
            w = COL_WIDTHS.get(col, 100)
            self.tree.heading(col, text=col, anchor="w",
                              command=lambda c=col: self._sort_column(c))
            self.tree.column(col, width=w, minwidth=w,
                             stretch=(self.sheet_name.lower() != "tasks" or col == "TaskName"), anchor="w")

        # ── Scrollbars ───────────────────────────────────────────────────────
        vsb = ttk.Scrollbar(tree_frame, orient="vertical",
                            command=self.tree.yview,
                            style="Excel.Vertical.TScrollbar")
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal",
                            command=self.tree.xview,
                            style="Excel.Horizontal.TScrollbar")
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")


        self.load_data()

    # ══════════════════════════════════════════════════════════════════════════
    # INLINE PROGRESS BARS  (no-op — progress shown as plain text in cell)
    # ══════════════════════════════════════════════════════════════════════════
    def _redraw_progress(self):
        pass

    # ══════════════════════════════════════════════════════════════════════════
    # LOAD DATA
    # ══════════════════════════════════════════════════════════════════════════
    def load_data(self):
        self._row_counter = 0
        df = self.data_service.get_sheet_data(self.sheet_name)

        if self.sheet_name.lower() != "tasks":
            for i, row in enumerate(df.to_dict("records")):
                values = []
                for col in self._display_columns:
                    val = row.get(col)
                    if isinstance(val, float) and math.isnan(val):
                        val = ""
                    values.append(val)
                tag = "odd" if i % 2 == 0 else "even"
                if self.sheet_name.lower() == "projectstatus":
                    s = str(row.get("AutoStatus", "")).lower()
                    if s == "green":
                        tag = "green"
                    elif s == "amber":
                        tag = "amber"
                    elif s == "red":
                        tag = "red"
                self.tree.insert("", "end", values=values, tags=(tag,))
            return

        # ── Tasks: merge ProjectName ─────────────────────────────────────────
        try:
            projects_df = self.data_service.get_sheet_data("Projects")
            if not projects_df.empty and "ProjectName" in projects_df.columns:
                if "ProjectName" in df.columns:
                    df = df.drop(columns=["ProjectName"])
                df = df.merge(
                    projects_df[["ProjectID", "ProjectName"]],
                    on="ProjectID", how="left"
                )
                df["ProjectName"] = df["ProjectName"].fillna("Unknown").astype(str)
        except Exception as e:
            print(f"Warning: could not merge ProjectName: {e}")
            df["ProjectName"] = "Unknown"

        tasks = df.to_dict("records")

        from collections import OrderedDict
        projects_map = OrderedDict()
        for t in tasks:
            pid   = str(t.get("ProjectID", ""))
            pname = t.get("ProjectName", "Unknown")
            if pid not in projects_map:
                projects_map[pid] = {"name": pname, "tasks": []}
            projects_map[pid]["tasks"].append(t)

        builder = TaskHierarchyBuilder()

        for pid, pdata in projects_map.items():
            blank_values = [""] * len(self._display_columns)
            proj_item = self.tree.insert(
                "", "end",
                text=f"  📁  {pdata['name']}",
                values=blank_values,
                tags=("project_header",),
                open=True,
            )
            tree_nodes = builder.build_tree(pdata["tasks"])
            self.insert_tree_nodes(proj_item, tree_nodes, depth=0)


    # ══════════════════════════════════════════════════════════════════════════
    # INSERT TREE NODES
    # ══════════════════════════════════════════════════════════════════════════
    def insert_tree_nodes(self, parent, nodes, depth=0):
        indent = "  " * depth
        for node in nodes:
            self._row_counter += 1
            row_num  = self._row_counter
            is_parent = bool(node.get("children"))

            values = []
            for col in self._display_columns:
                val = node.get(col)
                if isinstance(val, float) and math.isnan(val):
                    val = None
                values.append(val)

            row_tag = "parent" if is_parent else (
                "odd" if row_num % 2 == 0 else "even")

            item = self.tree.insert(
                parent, "end",
                text=f"  {row_num}  {indent}{node.get('TaskName', '')}",
                values=values,
                tags=(row_tag,),
                open=True,
            )
            if is_parent:
                self.insert_tree_nodes(item, node["children"], depth=depth + 1)

    # ══════════════════════════════════════════════════════════════════════════
    # SORT COLUMN (click heading)
    # ══════════════════════════════════════════════════════════════════════════
    def _sort_column(self, col):
        if not hasattr(self, "_sort_state"):
            self._sort_state = {}
        reverse = self._sort_state.get(col, False)
        self._sort_state[col] = not reverse

        col_idx = self._display_columns.index(col) if col in self._display_columns else -1
        if col_idx < 0:
            return

        for proj_item in self.tree.get_children(""):
            children = list(self.tree.get_children(proj_item))

            def sort_key(item):
                vals = self.tree.item(item, "values")
                try:
                    return (0, float(vals[col_idx]))
                except Exception:
                    return (1, str(vals[col_idx]).lower())

            children.sort(key=sort_key, reverse=reverse)
            for idx, child in enumerate(children):
                self.tree.move(child, proj_item, idx)

        arrow = " ▲" if not reverse else " ▼"
        # reset others
        for c in self._display_columns:
            base = c.rstrip(" ▲▼")
            self.tree.heading(c, text=base + (arrow if c == col else ""))

    # ══════════════════════════════════════════════════════════════════════════
    # REFRESH
    # ══════════════════════════════════════════════════════════════════════════
    def refresh(self):
        print("🔄 Refreshing UI...")
        for row in self.tree.get_children():
            self.tree.delete(row)
        self.load_data()

    # ══════════════════════════════════════════════════════════════════════════
    # METRICS
    # ══════════════════════════════════════════════════════════════════════════
    def update_project_metrics(self, project_id):
        try:
            self.data_service.update_project_metrics(project_id)
        except Exception as e:
            print(f"⚠️ Metrics update failed: {e}")

    def recalculate_all_projects(self):
        print("📊 Recalculating all project statuses...")
        try:
            projects_df = self.data_service.get_sheet_data("Projects")
            for proj in projects_df.to_dict("records"):
                pid = proj.get("ProjectID")
                if pid:
                    self.data_service.update_project_metrics(pid)
            print("✅ All project statuses updated")
        except Exception as e:
            print(f"❌ Error: {e}")
        self.refresh()

    # ══════════════════════════════════════════════════════════════════════════
    # HELPER: TaskID from item
    # ══════════════════════════════════════════════════════════════════════════
    def _get_task_id_from_item(self, item):
        values = self.tree.item(item, "values")
        if not values:
            return None
        try:
            val = float(values[0])
            return None if math.isnan(val) else int(val)
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════════════════
    # ADD RECORD
    # ══════════════════════════════════════════════════════════════════════════
    def add_record(self):
        form_columns = [c for c in self._excel_columns
                        if c not in ["TaskID", "ParentTaskID"]]

        def save(data):
            data = self.clean_data(data)
            if self.sheet_name.lower() == "tasks":
                data["TaskID"]       = self.data_service.generate_task_id()
                data["ParentTaskID"] = None
                tasks = self.data_service.get_sheet_data("Tasks").to_dict("records")
                tasks.append(data)
                validator = HierarchyValidator()
                try:
                    validator.validate(tasks)
                except Exception as e:
                    print(f"❌ {e}")
                    return
            self.data_service.add_row(self.sheet_name, data)
            if self.sheet_name.lower() == "tasks":
                self.update_project_metrics(data.get("ProjectID"))
            self.refresh()

        DynamicForm(self, form_columns, save,
                    sheet_name=self.sheet_name, data_service=self.data_service)

    # ══════════════════════════════════════════════════════════════════════════
    # ADD SUBTASK
    # ══════════════════════════════════════════════════════════════════════════
    def add_subtask(self):
        if self.sheet_name.lower() != "tasks":
            return
        selected = self.tree.focus()
        if not selected:
            print("Select a task first")
            return
        tags = self.tree.item(selected, "tags")
        if "project_header" in tags:
            messagebox.showwarning("Select a task", "Please select a task row first.")
            return

        values         = self.tree.item(selected, "values")
        parent_task_id = values[0]
        project_id     = values[1]

        form_columns = [c for c in self._excel_columns
                        if c not in ["TaskID", "ProjectID", "ParentTaskID"]]

        def save(data):
            data = self.clean_data(data)
            data["TaskID"] = self.data_service.generate_task_id()
            try:
                if parent_task_id is None or str(parent_task_id).lower() in ["nan", "none", ""]:
                    data["ParentTaskID"] = None
                else:
                    val = float(parent_task_id)
                    data["ParentTaskID"] = None if math.isnan(val) else int(val)
            except Exception:
                data["ParentTaskID"] = None
            data["ProjectID"] = project_id
            tasks = self.data_service.get_sheet_data("Tasks").to_dict("records")
            tasks.append(data)
            validator = HierarchyValidator()
            try:
                validator.validate(tasks)
            except Exception as e:
                print(f"❌ {e}")
                return
            self.data_service.add_row(self.sheet_name, data)
            self.update_project_metrics(project_id)
            self.refresh()

        DynamicForm(self, form_columns, save,
                    sheet_name=self.sheet_name, data_service=self.data_service)

    # ══════════════════════════════════════════════════════════════════════════
    # EDIT RECORD
    # ══════════════════════════════════════════════════════════════════════════
    def edit_record(self):
        selected = self.tree.focus()
        if not selected:
            return
        tags = self.tree.item(selected, "tags")
        if "project_header" in tags:
            return

        values     = self.tree.item(selected, "values")
        key_column = self._excel_columns[0]
        key_value  = values[0]

        def save(data):
            data = self.clean_data(data)
            original_project_id = None
            if self.sheet_name.lower() == "tasks":
                tasks = self.data_service.get_sheet_data("Tasks").to_dict("records")
                for t in tasks:
                    if str(t.get("TaskID")) == str(key_value):
                        orig_tid  = t.get("TaskID")
                        orig_pid  = t.get("ParentTaskID")
                        original_project_id = t.get("ProjectID")
                        for k, v in data.items():
                            t[k] = v
                        t["TaskID"]       = orig_tid
                        t["ParentTaskID"] = orig_pid
                        t["ProjectID"]    = original_project_id
                        break
                validator = HierarchyValidator()
                try:
                    validator.validate(tasks)
                except Exception as e:
                    print(f"❌ {e}")
                    return
                import pandas as pd
                self.data_service.repo.write_sheet("Tasks", pd.DataFrame(tasks))
                self.update_project_metrics(original_project_id)
            else:
                self.data_service.update_row_by_id(
                    self.sheet_name, key_column, key_value, data)
            self.refresh()

        display_list = list(self._display_columns)
        excel_values = [
            values[display_list.index(col)] if col in display_list else ""
            for col in self._excel_columns
        ]
        DynamicForm(self, self._excel_columns, save, excel_values,
                    sheet_name=self.sheet_name, data_service=self.data_service)

    # ══════════════════════════════════════════════════════════════════════════
    # DELETE RECORD  (fixed — uses TaskID not visual index)
    # ══════════════════════════════════════════════════════════════════════════
    def delete_record(self):
        selected = self.tree.focus()
        if not selected:
            return
        tags = self.tree.item(selected, "tags")
        if "project_header" in tags:
            messagebox.showwarning("Select a task",
                                   "Please select a task row, not a project header.")
            return

        values = self.tree.item(selected, "values")

        if self.sheet_name.lower() == "tasks":
            task_id = self._get_task_id_from_item(selected)
            if task_id is None:
                messagebox.showerror("Error", "Could not determine TaskID.")
                return
            project_id = values[1] if len(values) > 1 else None
            task_name  = (self.tree.item(selected, "text")
                          .strip().lstrip("0123456789 ").strip())

            if not messagebox.askyesno(
                "Confirm Delete",
                f"Delete task '{task_name}' (ID {task_id})?\n\n"
                "Child subtasks will become root-level tasks."
            ):
                return

            import pandas as pd
            tasks_df = self.data_service.get_sheet_data("Tasks")
            tasks_df = tasks_df[tasks_df["TaskID"].astype(str) != str(task_id)]
            self.data_service.repo.write_sheet("Tasks", tasks_df)
            self.update_project_metrics(project_id)
        else:
            row_index = self.tree.index(selected)
            self.data_service.delete_row(self.sheet_name, row_index)

        self.refresh()

    # ══════════════════════════════════════════════════════════════════════════
    # CORE RE-PARENT  (shared by drag-drop + dialog)
    # ══════════════════════════════════════════════════════════════════════════
    def _do_reparent(self, src_task_id, src_project_id,
                     new_parent_id, new_project_id, src_name, target_label):
        """
        KEY FIX for "invalid parent id":
        When moving a subtask we MUST update BOTH:
          1. ParentTaskID  → new_parent_id  (or None for root)
          2. ProjectID     → new_project_id (the target parent's project)

        Previously only ParentTaskID was changed.  Leaving the old ProjectID
        meant the task referenced a ParentTaskID that belonged to a different
        project, which the HierarchyValidator correctly rejected.
        """
        import pandas as pd

        tasks_df = self.data_service.get_sheet_data("Tasks")
        mask = tasks_df["TaskID"].astype(str) == str(src_task_id)

        # 1. ParentTaskID
        tasks_df.loc[mask, "ParentTaskID"] = (
            new_parent_id if new_parent_id is not None else None
        )

        # 2. ProjectID  ← the actual fix
        if new_project_id is not None:
            tasks_df.loc[mask, "ProjectID"] = new_project_id

        # 3. Validate
        validator = HierarchyValidator()
        try:
            validator.validate(tasks_df.to_dict("records"))
        except Exception as e:
            messagebox.showerror("Hierarchy Error",
                                 f"Cannot move task:\n{e}")
            return False

        # 4. Persist
        self.data_service.repo.write_sheet("Tasks", tasks_df)
        self.update_project_metrics(src_project_id)
        if new_project_id and str(new_project_id) != str(src_project_id):
            self.update_project_metrics(new_project_id)

        self.refresh()
        print(f"✅ '{src_name}' → '{target_label}'  "
              f"(ParentTaskID={new_parent_id}, ProjectID={new_project_id})")
        return True

    # ══════════════════════════════════════════════════════════════════════════
    # RIGHT-CLICK CONTEXT MENU
    # ══════════════════════════════════════════════════════════════════════════
    def _show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if not item:
            return
        self.tree.selection_set(item)
        self.tree.focus(item)
        tags = self.tree.item(item, "tags")
        if "project_header" in tags:
            return

        menu = tk.Menu(self, tearoff=0, font=_FONT_BODY,
                       bg="white", activebackground=_ROW_SELECTED,
                       activeforeground="#000000",
                       relief="solid", bd=1)
        menu.add_command(label="  ✏️   Edit",           command=self.edit_record)
        menu.add_command(label="  ➕   Add Subtask",     command=self.add_subtask)
        menu.add_separator()
        menu.add_command(label="  ↖️   Assign / Change Parent",
                         command=self.assign_parent_task)
        menu.add_separator()
        menu.add_command(label="  🗑️   Delete",          command=self.delete_record)
        menu.tk_popup(event.x_root, event.y_root)

    # ══════════════════════════════════════════════════════════════════════════
    # ASSIGN PARENT DIALOG  (context menu / toolbar hook)
    # ══════════════════════════════════════════════════════════════════════════
    def assign_parent_task(self):
        if self.sheet_name.lower() != "tasks":
            return
        selected = self.tree.focus()
        if not selected:
            messagebox.showinfo("No selection", "Please select a task first.")
            return
        tags = self.tree.item(selected, "tags")
        if "project_header" in tags:
            return

        values         = self.tree.item(selected, "values")
        task_id        = self._get_task_id_from_item(selected)
        src_project_id = values[1] if len(values) > 1 else None
        task_name      = (self.tree.item(selected, "text")
                          .strip().lstrip("0123456789 ").strip())

        if task_id is None:
            messagebox.showerror("Error", "Could not read TaskID.")
            return

        tasks_df   = self.data_service.get_sheet_data("Tasks")
        candidates = [
            (int(r["TaskID"]),
             f"[{int(r['TaskID'])}]  {r.get('TaskName', '')}  "
             f"— Project {r.get('ProjectID', '?')}")
            for _, r in tasks_df.iterrows()
            if str(r["TaskID"]) != str(task_id)
        ]

        dialog = _ParentPickerDialog(self, task_name=task_name,
                                     candidates=candidates)
        self.wait_window(dialog)

        if not dialog.result_confirmed:
            return

        chosen_parent_id = dialog.chosen_parent_id

        if chosen_parent_id is not None:
            parent_rows = tasks_df[
                tasks_df["TaskID"].astype(str) == str(chosen_parent_id)
            ]
            if parent_rows.empty:
                messagebox.showerror("Error",
                                     f"Task ID {chosen_parent_id} not found.")
                return
            new_project_id = parent_rows.iloc[0].get("ProjectID", src_project_id)
        else:
            new_project_id = src_project_id

        self._do_reparent(
            src_task_id    = task_id,
            src_project_id = src_project_id,
            new_parent_id  = chosen_parent_id,
            new_project_id = new_project_id,
            src_name       = task_name,
            target_label   = (str(chosen_parent_id)
                              if chosen_parent_id else "root (no parent)"),
        )

    # ══════════════════════════════════════════════════════════════════════════
    # DRAG-AND-DROP
    # ══════════════════════════════════════════════════════════════════════════
    def _on_drag_start(self, event):
        item = self.tree.identify_row(event.y)
        if not item:
            self._drag_source_item = None
            return
        if "project_header" in self.tree.item(item, "tags"):
            self._drag_source_item = None
            return
        self._drag_source_item = item

    def _on_drag_motion(self, event):
        if not self._drag_source_item:
            return
        target = self.tree.identify_row(event.y)

        for item in list(self.tree.tag_has("drag_target")):
            t = [x for x in self.tree.item(item, "tags") if x != "drag_target"]
            self.tree.item(item, tags=t)

        if target and target != self._drag_source_item:
            t = list(self.tree.item(target, "tags"))
            if "project_header" not in t:
                t.append("drag_target")
                self.tree.item(target, tags=t)

        if self._drag_tooltip:
            self._drag_tooltip.destroy()
        src_name = (self.tree.item(self._drag_source_item, "text")
                    .strip().lstrip("0123456789 ").strip())
        tip = tk.Toplevel(self)
        tip.wm_overrideredirect(True)
        tip.wm_geometry(f"+{event.x_root + 16}+{event.y_root + 8}")
        tk.Label(tip, text=f"↖  Move:  {src_name}",
                 bg=_COL_HEADER_BG, fg="white",
                 font=("Calibri", 9, "bold"), padx=10, pady=4).pack()
        self._drag_tooltip = tip

    def _on_drag_release(self, event):
        if self._drag_tooltip:
            self._drag_tooltip.destroy()
            self._drag_tooltip = None

        for item in list(self.tree.tag_has("drag_target")):
            t = [x for x in self.tree.item(item, "tags") if x != "drag_target"]
            self.tree.item(item, tags=t)

        src = self._drag_source_item
        self._drag_source_item = None
        if not src:
            return

        target = self.tree.identify_row(event.y)
        if not target or target == src:
            return

        target_tags    = self.tree.item(target, "tags")
        src_task_id    = self._get_task_id_from_item(src)
        if src_task_id is None:
            return

        src_values     = self.tree.item(src, "values")
        src_project_id = src_values[1] if len(src_values) > 1 else None
        src_name       = (self.tree.item(src, "text")
                          .strip().lstrip("0123456789 ").strip())

        if "project_header" in target_tags:
            new_parent_id  = None
            new_project_id = src_project_id
            target_label   = "(root of project)"
        else:
            target_task_id = self._get_task_id_from_item(target)
            if target_task_id is None or target_task_id == src_task_id:
                return
            new_parent_id  = target_task_id
            target_values  = self.tree.item(target, "values")
            # ── KEY FIX: get ProjectID from the TARGET row ───────────────────
            new_project_id = (target_values[1] if len(target_values) > 1
                              else src_project_id)
            target_label   = (self.tree.item(target, "text")
                              .strip().lstrip("0123456789 ").strip()
                              or str(new_parent_id))

        if not messagebox.askyesno("Move Task",
                                   f"Move  '{src_name}'\nunder  '{target_label}'?"):
            return

        self._do_reparent(
            src_task_id    = src_task_id,
            src_project_id = src_project_id,
            new_parent_id  = new_parent_id,
            new_project_id = new_project_id,
            src_name       = src_name,
            target_label   = target_label,
        )

    # ══════════════════════════════════════════════════════════════════════════
    # SCROLL
    # ══════════════════════════════════════════════════════════════════════════
    def on_mouse_wheel(self, event):
        self.tree.yview_scroll(int(-1 * (event.delta / 60)), "units")


# ══════════════════════════════════════════════════════════════════════════════
# PARENT PICKER DIALOG
# ══════════════════════════════════════════════════════════════════════════════
class _ParentPickerDialog(tk.Toplevel):

    def __init__(self, parent, task_name, candidates):
        super().__init__(parent)
        self.title("Assign / Change Parent Task")
        self.resizable(True, True)
        self.grab_set()
        self.configure(bg="white")

        self.result_confirmed = False
        self.chosen_parent_id = None
        self.candidates       = candidates

        # header bar
        hdr = tk.Frame(self, bg=_COL_HEADER_BG, height=44)
        hdr.pack(fill="x")
        tk.Label(hdr,
                 text=f"  Select new parent for:  \"{task_name}\"",
                 bg=_COL_HEADER_BG, fg="white",
                 font=_FONT_BOLD, pady=11, padx=12).pack(side="left")

        body = tk.Frame(self, bg="white", padx=16, pady=10)
        body.pack(fill="both", expand=True)

        # search
        search_row = tk.Frame(body, bg="white")
        search_row.pack(fill="x", pady=(0, 8))
        tk.Label(search_row, text="🔍  Search:", bg="white",
                 font=_FONT_BODY).pack(side="left")
        self._search_var = tk.StringVar()
        self._search_var.trace_add("write", self._filter_list)
        ent = tk.Entry(search_row, textvariable=self._search_var,
                       font=_FONT_BODY, width=36,
                       relief="solid", bd=1)
        ent.pack(side="left", padx=8)
        ent.focus_set()

        # list
        list_frame = tk.Frame(body, bg=_GRID_LINE, bd=1, relief="solid")
        list_frame.pack(fill="both", expand=True)
        sb = tk.Scrollbar(list_frame, orient="vertical")
        self._listbox = tk.Listbox(
            list_frame, height=14, width=56,
            yscrollcommand=sb.set,
            selectmode="single",
            font=_FONT_BODY,
            bg="white", selectbackground=_ROW_SELECTED,
            selectforeground="#000000",
            activestyle="none",
            bd=0, highlightthickness=0,
        )
        sb.config(command=self._listbox.yview)
        sb.pack(side="right", fill="y")
        self._listbox.pack(side="left", fill="both", expand=True, padx=1, pady=1)
        self._populate_list(candidates)
        self._listbox.bind("<Double-Button-1>", lambda e: self._choose_selected())

        # buttons
        btn_row = tk.Frame(self, bg="white", pady=10, padx=16)
        btn_row.pack(fill="x")

        def _btn(text, cmd, bg, width=22):
            b = tk.Button(btn_row, text=text, command=cmd,
                          bg=bg, fg="white", font=_FONT_BOLD,
                          relief="flat", bd=0, padx=10, pady=6,
                          cursor="hand2", width=width,
                          activebackground=bg, activeforeground="white")
            b.pack(side="left", padx=4)

        _btn("↖  Make Root Task (no parent)", self._choose_root,  "#767676", 28)
        _btn("✔  Assign Selected",             self._choose_selected, _COL_HEADER_BG, 20)
        _btn("✖  Cancel",                      self.destroy,      "#A00000", 10)

        self.update_idletasks()
        px = max(0, parent.winfo_rootx() + parent.winfo_width()  // 2 - self.winfo_width()  // 2)
        py = max(0, parent.winfo_rooty() + parent.winfo_height() // 2 - self.winfo_height() // 2)
        self.geometry(f"+{px}+{py}")

    def _populate_list(self, items):
        self._listbox.delete(0, "end")
        self._filtered_ids = []
        for i, (tid, label) in enumerate(items):
            self._listbox.insert("end", f"  {label}")
            self._listbox.itemconfig(
                i, background=_ROW_ODD if i % 2 == 0 else _ROW_EVEN)
            self._filtered_ids.append(tid)

    def _filter_list(self, *_):
        q = self._search_var.get().lower()
        filtered = [(tid, lbl) for tid, lbl in self.candidates
                    if q in lbl.lower() or q in str(tid)]
        self._populate_list(filtered)

    def _choose_root(self):
        self.chosen_parent_id = None
        self.result_confirmed = True
        self.destroy()

    def _choose_selected(self):
        sel = self._listbox.curselection()
        if not sel:
            messagebox.showwarning("No selection",
                                   "Please select a task from the list.",
                                   parent=self)
            return
        self.chosen_parent_id = self._filtered_ids[sel[0]]
        self.result_confirmed = True
        self.destroy()