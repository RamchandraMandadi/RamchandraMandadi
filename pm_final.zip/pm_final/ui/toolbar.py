import tkinter as tk
from tkinter import ttk


class CommandToolbar(ttk.Frame):

    def __init__(self, parent, add_callback,add_subtask_callback, edit_callback, delete_callback, refresh_callback,recalc_callback=None):

        super().__init__(parent)

        ttk.Button(self, text="➕ Add", command=add_callback).pack(side="left", padx=5)
        ttk.Button(self, text="🧩 Subtask", command=add_subtask_callback).pack(side="left", padx=5)
        ttk.Button(self, text="✏️ Edit", command=edit_callback).pack(side="left", padx=5)
        ttk.Button(self, text="🗑 Delete", command=delete_callback).pack(side="left", padx=5)
        ttk.Button(self, text="🔄 Refresh", command=refresh_callback).pack(side="left", padx=5)

        if recalc_callback:
            ttk.Button(self, text="📊 Recalculate", command=recalc_callback).pack(side="left", padx=5)
        