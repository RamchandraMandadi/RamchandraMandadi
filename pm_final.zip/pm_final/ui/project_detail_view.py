"""
project_detail_view.py  — Project detail: info + RAG + full task CRUD
Fixes:
  • Add / Edit / Delete tasks → saved to Excel Tasks sheet
  • Row colours based on Status AND dates (overdue detection)
  • $nan fix for missing budget/spent
"""

import tkinter as tk
from tkinter import ttk, messagebox
import math
import datetime

C = {
    'bg':     '#f0f2f7', 'surface': '#ffffff', 'border': '#dde1ed',
    'ink':    '#000000', 'ink2':    '#000000', 't2':     '#000000',
    'accent': '#2952e3', 'topbar':  '#000000',
    'R':      '#e53935', 'A':       '#f59e0b', 'G':      '#16a34a',
}

# ── Colour logic ───────────────────────────────────────────────────────────────
def _safe_float(v):
    try:
        f = float(v)
        return 0.0 if f != f else f
    except:
        return 0.0

def _parse_date(v):
    if not v or str(v).strip() in ('', 'nan', 'NaT', 'None'):
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y'):
        try:
            return datetime.datetime.strptime(str(v)[:10], fmt).date()
        except:
            pass
    return None

def task_row_color(status, start_date_str, end_date_str):
    """
    Returns (bg, fg, tag_name) based on status + dates.
    Priority: Completed > Overdue > At Risk > In Progress > Not Started
    """
    today  = datetime.date.today()
    end_dt = _parse_date(end_date_str)
    stat   = str(status).strip()

    if stat == 'Completed':
        return '#f0fdf4', '#16a34a', 'completed'   # green tint

    # Overdue = end date passed AND not completed
    if end_dt and end_dt < today and stat != 'Completed':
        return '#fdecea', '#e53935', 'overdue'      # red tint

    if stat == 'At Risk':
        return '#fff8e6', '#b45309', 'at_risk'      # amber tint

    if stat == 'In Progress':
        return '#eff6ff', '#1d4ed8', 'in_prog'      # blue tint

    if stat == 'On Hold':
        return '#f5f3ff', '#7c3aed', 'on_hold'      # purple tint

    return '#f7f8fc', '#000000', 'not_started'      # grey


def rag_color(s):
    return {'R': C['R'], 'A': C['A'], 'G': C['G']}.get(s, C['G'])


# ══════════════════════════════════════════════════════════════════════════════
class ProjectDetailView(tk.Frame):

    def __init__(self, parent, svc, pid, on_back=None):
        super().__init__(parent, bg=C['bg'])
        self.svc     = svc
        self.pid     = str(pid)
        self.on_back = on_back
        self._build()

    # ──────────────────────────────────────────────────────────────────────────
    def _build(self):
        project = self.svc.get_project(self.pid)
        p_rag   = self.svc.get_project_rag(self.pid)

        # ── sub-header bar ────────────────────────────────────────────────────
        bar = tk.Frame(self, bg=C['topbar'], height=44)
        bar.pack(fill='x')
        bar.pack_propagate(False)

        tk.Button(bar, text='← Back',
                  font=('Segoe UI', 9), bg=C['topbar'], fg='#ffffff',
                  activebackground='#1a2845', activeforeground='white',
                  relief='flat', bd=0, padx=12, cursor='hand2',
                  command=self.on_back).pack(side='left', pady=8)

        tk.Label(bar, text=project.get('ProjectName', ''),
                 font=('Segoe UI', 11, 'bold'),
                 bg=C['topbar'], fg='white').pack(side='left', padx=8)

        # Timeline button
        tk.Button(bar, text='📅  Timeline',
                  font=('Segoe UI', 9),
                  bg='#1a2845', fg='#ffffff',
                  activebackground='#2952e3', activeforeground='white',
                  relief='flat', bd=0, padx=12, cursor='hand2',
                  command=self._open_timeline).pack(side='right', pady=8, padx=8)

        # ── scrollable body ───────────────────────────────────────────────────
        outer = tk.Frame(self, bg=C['bg'])
        outer.pack(fill='both', expand=True)

        canvas = tk.Canvas(outer, bg=C['bg'], highlightthickness=0)
        vsb    = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner  = tk.Frame(canvas, bg=C['bg'])
        win_id = canvas.create_window((0, 0), window=inner, anchor='nw')
        inner.bind('<Configure>',
                   lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfig(win_id, width=e.width))
        canvas.bind_all('<MouseWheel>',
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 60)), 'units'))

        pad = tk.Frame(inner, bg=C['bg'], padx=22, pady=16)
        pad.pack(fill='both', expand=True)

        self._info_row(pad, project, p_rag)
        self._tasks_section(pad)

    # ── Project info + RAG row ────────────────────────────────────────────────
    def _info_row(self, parent, p, p_rag):
        row = tk.Frame(parent, bg=C['bg'])
        row.pack(fill='x', pady=(0, 16))

        # Info card
        info = tk.Frame(row, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        info.pack(side='left', fill='both', expand=True, padx=(0, 10))

        tk.Label(info, text='Project Info',
                 font=('Segoe UI', 10, 'bold'),
                 bg=C['surface'], fg=C['ink'],
                 anchor='w').pack(fill='x', padx=14, pady=(12, 6))
        tk.Frame(info, bg=C['border'], height=1).pack(fill='x')

        budget = _safe_float(p.get('Budget', 0))
        spent  = _safe_float(p.get('Spent', 0))

        for label, value in [
            ('Manager',    p.get('Manager', '')),
            ('Client',     p.get('Client', '')),
            ('Department', p.get('Department', '')),
            ('Priority',   p.get('Priority', '')),
            ('Start Date', str(p.get('StartDate', ''))),
            ('End Date',   str(p.get('EndDate', ''))),
            ('Budget',     f'${budget:,.0f}'),
            ('Spent',      f'${spent:,.0f}'),
        ]:
            r = tk.Frame(info, bg=C['surface'])
            r.pack(fill='x', padx=14, pady=3)
            tk.Label(r, text=label + ':', font=('Segoe UI', 8, 'bold'),
                     bg=C['surface'], fg=C['t2'],
                     width=12, anchor='w').pack(side='left')
            tk.Label(r, text=str(value), font=('Segoe UI', 9),
                     bg=C['surface'], fg=C['ink2'],
                     anchor='w').pack(side='left')

        # RAG card
        rag_card = tk.Frame(row, bg=C['surface'],
                            highlightbackground=C['border'], highlightthickness=1)
        rag_card.pack(side='left', fill='both', expand=True)

        # RAG header with Edit button
        rag_hdr = tk.Frame(rag_card, bg=C['surface'])
        rag_hdr.pack(fill='x', padx=14, pady=(12, 6))
        tk.Label(rag_hdr, text='RAG Status',
                 font=('Segoe UI', 10, 'bold'),
                 bg=C['surface'], fg=C['ink']).pack(side='left')
        tk.Button(rag_hdr, text='✏  Edit RAG',
                  font=('Segoe UI', 8, 'bold'),
                  bg=C['accent'], fg='white',
                  activebackground='#3461f0', activeforeground='white',
                  relief='flat', bd=0, padx=10, pady=4,
                  cursor='hand2',
                  command=lambda: self._edit_rag(rag_card, p, p_rag)
                  ).pack(side='right')
        tk.Frame(rag_card, bg=C['border'], height=1).pack(fill='x')

        from services.portfolio_service import RAG_ASPECTS
        grid = tk.Frame(rag_card, bg=C['surface'])
        grid.pack(padx=14, pady=10, fill='x')
        for ci in range(5):
            grid.columnconfigure(ci, weight=1)
        for i, asp in enumerate(RAG_ASPECTS):
            s    = p_rag.get(asp, {}).get('status', 'G')
            cell = tk.Frame(grid, bg=C['surface'])
            cell.grid(row=i // 5, column=i % 5, padx=4, pady=4, sticky='ew')
            tk.Label(cell, text=s, width=3,
                     bg=rag_color(s), fg='white',
                     font=('Segoe UI', 10, 'bold'), pady=4).pack()
            tk.Label(cell, text=asp, font=('Segoe UI', 7),
                     bg=C['surface'], fg=C['t2'],
                     wraplength=60).pack()

    # ── Tasks section ─────────────────────────────────────────────────────────
    def _tasks_section(self, parent):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.pack(fill='both', expand=True)

        # ── Tasks header + toolbar ────────────────────────────────────────────
        hdr = tk.Frame(card, bg=C['surface'])
        hdr.pack(fill='x', padx=16, pady=(12, 6))

        tk.Label(hdr, text='Tasks',
                 font=('Segoe UI', 11, 'bold'),
                 bg=C['surface'], fg=C['ink']).pack(side='left')

        # toolbar buttons
        for label, icon, cmd, bg in [
            ('Add Task',  '＋', self._add_task,    '#2952e3'),
            ('Edit',      '✏',  self._edit_task,   '#475569'),
            ('Delete',    '🗑',  self._delete_task, '#e53935'),
            ('Refresh',   '↻',  self._refresh_tasks, '#16a34a'),
        ]:
            tk.Button(hdr, text=f'{icon}  {label}',
                      font=('Segoe UI', 9, 'bold'),
                      bg=bg, fg='white',
                      activebackground=bg, activeforeground='white',
                      relief='flat', bd=0, padx=10, pady=5,
                      cursor='hand2', command=cmd).pack(side='right', padx=3)

        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        # ── Colour legend ─────────────────────────────────────────────────────
        leg = tk.Frame(card, bg=C['surface'])
        leg.pack(fill='x', padx=16, pady=6)
        tk.Label(leg, text='Colours:', font=('Segoe UI', 8, 'bold'),
                 bg=C['surface'], fg=C['t2']).pack(side='left', padx=(0, 8))
        for lbl, bg, fg in [
            ('Completed',   '#f0fdf4', '#16a34a'),
            ('In Progress', '#eff6ff', '#1d4ed8'),
            ('At Risk',     '#fff8e6', '#b45309'),
            ('Overdue',     '#fdecea', '#e53935'),
            ('On Hold',     '#f5f3ff', '#7c3aed'),
            ('Not Started', '#f7f8fc', '#000000'),
        ]:
            pill = tk.Label(leg, text=lbl,
                            font=('Segoe UI', 7, 'bold'),
                            bg=bg, fg=fg, padx=7, pady=2)
            pill.pack(side='left', padx=3)

        # ── Tree ──────────────────────────────────────────────────────────────
        self._tree_frame = tk.Frame(card, bg=C['surface'])
        self._tree_frame.pack(fill='both', expand=True, padx=8, pady=(4, 8))

        self._build_tree()

    # ── Build / Rebuild the treeview ──────────────────────────────────────────
    def _build_tree(self):
        for w in self._tree_frame.winfo_children():
            w.destroy()

        cols    = ('TaskName', 'Phase', 'AssignedTo',
                   'StartDate', 'EndDate', 'Status', 'Progress', 'Notes')
        col_w   = (180, 100, 120, 95, 95, 110, 75, 160)
        col_lbl = ('Task Name', 'Phase', 'Assigned To',
                   'Start Date', 'End Date', 'Status', 'Progress', 'Notes')

        style = ttk.Style()
        style.theme_use('default')          # ensures heading colours apply
        style.configure('Task.Treeview',
                        background='white', fieldbackground='white',
                        rowheight=34, font=('Segoe UI', 9))
        style.configure('Task.Treeview.Heading',
                        background='#1f2d4a', foreground='white',
                        font=('Segoe UI', 9, 'bold'), relief='flat',
                        padding=(6, 6))
        style.map('Task.Treeview.Heading',
                  background=[('active', '#2952e3')])
        style.map('Task.Treeview',
                  background=[('selected', '#dde8ff')],
                  foreground=[('selected', '#000000')])

        self.tree = ttk.Treeview(self._tree_frame, columns=cols,
                                 show='headings', style='Task.Treeview',
                                 selectmode='browse', height=14)

        vsb = ttk.Scrollbar(self._tree_frame, orient='vertical',
                             command=self.tree.yview)
        hsb = ttk.Scrollbar(self._tree_frame, orient='horizontal',
                             command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self._tree_frame.rowconfigure(0, weight=1)
        self._tree_frame.columnconfigure(0, weight=1)
        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')

        for col, lbl, w in zip(cols, col_lbl, col_w):
            self.tree.heading(col, text=lbl, anchor='w')
            self.tree.column(col, width=w, minwidth=w, anchor='w')

        # Configure tags with background + foreground
        for tag, bg, fg in [
            ('completed',  '#f0fdf4', '#16a34a'),
            ('overdue',    '#fdecea', '#e53935'),
            ('at_risk',    '#fff8e6', '#b45309'),
            ('in_prog',    '#eff6ff', '#1d4ed8'),
            ('on_hold',    '#f5f3ff', '#7c3aed'),
            ('not_started','#f7f8fc', '#000000'),
        ]:
            self.tree.tag_configure(tag, background=bg, foreground=fg)

        self._load_tasks()
        self.tree.bind('<Double-Button-1>', lambda e: self._edit_task())

    # ── Load tasks into tree ───────────────────────────────────────────────────
    def _load_tasks(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        tasks = self.svc.get_tasks(self.pid)
        cols  = ('TaskName', 'Phase', 'AssignedTo',
                 'StartDate', 'EndDate', 'Status', 'Progress', 'Notes')

        for t in tasks:
            vals = []
            for col in cols:
                v = t.get(col, '')
                if v is None or (isinstance(v, float) and math.isnan(v)):
                    v = ''
                elif col == 'Progress':
                    try:
                        v = f"{float(v):.0f}%"
                    except:
                        v = ''
                else:
                    v = str(v)
                vals.append(v)

            status   = str(t.get('Status', ''))
            start_d  = str(t.get('StartDate', ''))
            end_d    = str(t.get('EndDate', ''))
            _, _, tag = task_row_color(status, start_d, end_d)

            iid = f"{t.get('TaskID', '')}"
            self.tree.insert('', 'end', iid=iid if iid else None,
                             values=vals, tags=(tag,))

    # ── Refresh ────────────────────────────────────────────────────────────────
    def _refresh_tasks(self):
        self._load_tasks()

    # ── ADD TASK ──────────────────────────────────────────────────────────────
    def _add_task(self):
        _TaskDialog(self, self.svc, self.pid, task_data=None,
                    on_save=self._on_task_saved)

    # ── EDIT TASK ─────────────────────────────────────────────────────────────
    def _edit_task(self):
        sel = self.tree.focus()
        if not sel:
            messagebox.showinfo('Select a task', 'Please click a task row first.')
            return
        vals = self.tree.item(sel, 'values')
        if not vals:
            return
        cols = ('TaskName', 'Phase', 'AssignedTo',
                'StartDate', 'EndDate', 'Status', 'Progress', 'Notes')
        task_data          = dict(zip(cols, vals))
        task_data['TaskID']    = sel        # iid is always set to TaskID in _load_tasks
        task_data['ProjectID'] = self.pid
        prog = str(task_data.get('Progress', '0')).rstrip('%').strip()
        task_data['Progress']  = prog if prog else '0'
        _TaskDialog(self, self.svc, self.pid, task_data=task_data,
                    on_save=self._on_task_saved)

    # ── DELETE TASK ───────────────────────────────────────────────────────────
    def _delete_task(self):
        sel = self.tree.focus()
        if not sel:
            messagebox.showinfo('Select a task', 'Please click a task row first.')
            return
        task_name = self.tree.item(sel, 'values')[0]
        if messagebox.askyesno('Delete Task',
                               f'Delete task "{task_name}"?\nThis cannot be undone.'):
            self.svc.delete_task(sel, self.pid)
            self._load_tasks()

    def _on_task_saved(self):
        self._load_tasks()

    # ── Edit RAG dialog ───────────────────────────────────────────────────────
    def _edit_rag(self, rag_card, p, p_rag):
        """Open a dialog to edit all 10 RAG aspects, then refresh the card."""
        from services.portfolio_service import RAG_ASPECTS

        dlg = tk.Toplevel(self)
        dlg.title(f'Edit RAG — {p.get("ProjectName","")}')
        dlg.configure(bg='white')
        dlg.resizable(True, True)
        dlg.grab_set()
        dlg.geometry('560x560')
        pw = self.winfo_rootx() + self.winfo_width()  // 2 - 280
        ph = self.winfo_rooty() + self.winfo_height() // 2 - 280
        dlg.geometry(f'+{pw}+{ph}')

        # header
        hdr = tk.Frame(dlg, bg=C['topbar'], height=46)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text=f'  ✏  Edit RAG — {p.get("ProjectName","")}',
                 font=('Segoe UI', 11, 'bold'),
                 bg=C['topbar'], fg='white', pady=12).pack(side='left')

        # scrollable body
        canvas = tk.Canvas(dlg, bg='white', highlightthickness=0)
        vsb    = ttk.Scrollbar(dlg, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(fill='both', expand=True)
        body = tk.Frame(canvas, bg='white', padx=16, pady=12)
        wid  = canvas.create_window((0,0), window=body, anchor='nw')
        body.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfig(wid, width=e.width))

        # table header
        th = tk.Frame(body, bg='#000000')
        th.pack(fill='x')
        for ci, (lbl, w) in enumerate([('ASPECT',130),('STATUS',120),('EXPLANATION',260)]):
            tk.Label(th, text=lbl, font=('Segoe UI', 8, 'bold'),
                     bg='#000000', fg='#ffffff',
                     padx=8, pady=6, anchor='w',
                     width=w//7).grid(row=0, column=ci, sticky='ew')

        v_status = {}
        v_exp    = {}
        btn_refs = {}

        def _pick(asp, code, color):
            v_status[asp].set(code)
            for k, b in btn_refs[asp].items():
                b.config(bg=b.orig_col if k==code else '#e5e7eb',
                         fg='white' if k==code else '#000000',
                         relief='sunken' if k==code else 'flat')

        for i, asp in enumerate(RAG_ASPECTS):
            bg  = 'white' if i%2==0 else '#f7f8fc'
            cur = p_rag.get(asp, {})
            cur_s   = cur.get('status','G')
            cur_exp = cur.get('explanation','') or ''
            v_status[asp] = tk.StringVar(value=cur_s)
            v_exp[asp]    = tk.StringVar(value=cur_exp)

            r = tk.Frame(body, bg=bg)
            r.pack(fill='x')
            r.columnconfigure(2, weight=1)
            tk.Label(r, text=asp, font=('Segoe UI', 9),
                     bg=bg, fg=C['ink'], padx=8, pady=7,
                     anchor='w', width=130//7).grid(row=0, column=0, sticky='ew')

            bf = tk.Frame(r, bg=bg)
            bf.grid(row=0, column=1, sticky='w', padx=4)
            btn_refs[asp] = {}
            for code, col in [('R','#e53935'),('A','#f59e0b'),('G','#16a34a')]:
                b = tk.Button(bf, text=code, width=2,
                              bg=col if code==cur_s else '#e5e7eb',
                              fg='white' if code==cur_s else '#000000',
                              font=('Segoe UI', 8,'bold'),
                              relief='sunken' if code==cur_s else 'flat',
                              bd=0, padx=6, pady=3, cursor='hand2',
                              command=lambda a=asp,c=code,col=col: _pick(a,c,col))
                b.orig_col = col
                b.pack(side='left', padx=2)
                btn_refs[asp][code] = b

            tk.Entry(r, textvariable=v_exp[asp], font=('Segoe UI', 8),
                     relief='solid', bd=1, fg=C['t2']).grid(
                row=0, column=2, sticky='ew', padx=(4,8), pady=4)
            tk.Frame(body, bg=C['border'], height=1).pack(fill='x')

        # footer buttons
        footer = tk.Frame(dlg, bg='white', pady=10, padx=16)
        footer.pack(fill='x', side='bottom')

        def _save_rag():
            for asp in RAG_ASPECTS:
                self.svc.save_rag_entry(
                    self.pid, asp,
                    v_status[asp].get(),
                    v_exp[asp].get().strip()
                )
            dlg.destroy()
            # Refresh the info row
            self._refresh_info_row(rag_card, p)

        tk.Button(footer, text='💾  Save RAG',
                  font=('Segoe UI', 10, 'bold'),
                  bg=C['accent'], fg='white',
                  activebackground='#3461f0',
                  relief='flat', bd=0, padx=18, pady=8,
                  cursor='hand2', command=_save_rag).pack(side='right', padx=(8,0))
        tk.Button(footer, text='Cancel',
                  font=('Segoe UI', 10), bg='#f0f2f7', fg=C['ink'],
                  relief='flat', bd=0, padx=18, pady=8,
                  cursor='hand2', command=dlg.destroy).pack(side='right')

    def _refresh_info_row(self, rag_card, p):
        """Rebuild just the RAG grid after edits."""
        from services.portfolio_service import RAG_ASPECTS
        p_rag = self.svc.get_project_rag(self.pid)
        # destroy and rebuild the badge grid only
        for w in rag_card.winfo_children():
            w.destroy()
        # rebuild header
        rag_hdr = tk.Frame(rag_card, bg=C['surface'])
        rag_hdr.pack(fill='x', padx=14, pady=(12, 6))
        tk.Label(rag_hdr, text='RAG Status',
                 font=('Segoe UI', 10, 'bold'),
                 bg=C['surface'], fg=C['ink']).pack(side='left')
        tk.Button(rag_hdr, text='✏  Edit RAG',
                  font=('Segoe UI', 8, 'bold'),
                  bg=C['accent'], fg='white',
                  activebackground='#3461f0', activeforeground='white',
                  relief='flat', bd=0, padx=10, pady=4, cursor='hand2',
                  command=lambda: self._edit_rag(rag_card, p, p_rag)
                  ).pack(side='right')
        tk.Frame(rag_card, bg=C['border'], height=1).pack(fill='x')
        grid = tk.Frame(rag_card, bg=C['surface'])
        grid.pack(padx=14, pady=10, fill='x')
        for ci in range(5):
            grid.columnconfigure(ci, weight=1)
        for i, asp in enumerate(RAG_ASPECTS):
            s    = p_rag.get(asp, {}).get('status', 'G')
            cell = tk.Frame(grid, bg=C['surface'])
            cell.grid(row=i//5, column=i%5, padx=4, pady=4, sticky='ew')
            tk.Label(cell, text=s, width=3,
                     bg=rag_color(s), fg='white',
                     font=('Segoe UI', 10, 'bold'), pady=4).pack()
            tk.Label(cell, text=asp, font=('Segoe UI', 7),
                     bg=C['surface'], fg=C['t2'], wraplength=60).pack()

    def _open_timeline(self):
        """Open a full-window timeline for just this project."""
        import tkinter as tk_mod
        from ui.timeline_view import TimelineView

        win = tk_mod.Toplevel(self)
        win.title(f'Timeline — {self.svc.get_project(self.pid).get("ProjectName","")}')
        win.geometry('1200x600')
        win.configure(bg='#0F1117')

        svc = self.svc
        pid = self.pid

        class _SingleProjectSvc:
            def __init__(self):
                self.repo = svc.repo
            def get_hierarchy_ordered_tasks(self):
                p = svc.get_project(pid)
                rows = [{'TaskName': p.get('ProjectName',''),
                         'ProjectName': p.get('ProjectName',''),
                         'level': 0, 'is_project': True,
                         'ProjectID': pid}]
                for t in svc.get_tasks(pid):
                    r = dict(t); r['level']=1; r['is_project']=False
                    rows.append(r)
                return rows

        tv = TimelineView(win, _SingleProjectSvc(), sheet_name='Tasks')
        tv.pack(fill='both', expand=True)


# ══════════════════════════════════════════════════════════════════════════════
# TASK DIALOG  (Add / Edit)
# ══════════════════════════════════════════════════════════════════════════════
class _TaskDialog(tk.Toplevel):

    STATUSES = ['Not Started', 'In Progress', 'Completed', 'At Risk', 'On Hold']
    PHASES   = ['Initiating', 'Planning', 'Executing', 'Closing', 'Monitoring']

    def __init__(self, parent, svc, pid, task_data=None, on_save=None):
        super().__init__(parent)
        self.svc       = svc
        self.pid       = pid
        self.task_data = task_data or {}
        self.on_save   = on_save
        self.is_edit   = bool(task_data and task_data.get('TaskID'))

        self.title('Edit Task' if self.is_edit else 'Add Task')
        self.resizable(False, False)
        self.configure(bg='white')
        self.grab_set()
        self._build()
        self.update_idletasks()
        pw = parent.winfo_rootx() + parent.winfo_width()  // 2
        ph = parent.winfo_rooty() + parent.winfo_height() // 2
        self.geometry(f'+{pw - self.winfo_width()//2}+{ph - self.winfo_height()//2}')

    def _build(self):
        # Header
        hdr = tk.Frame(self, bg=C['topbar'], height=46)
        hdr.pack(fill='x')
        icon = '✏  Edit Task' if self.is_edit else '＋  Add Task'
        tk.Label(hdr, text=icon,
                 font=('Segoe UI', 11, 'bold'),
                 bg=C['topbar'], fg='white',
                 padx=16, pady=11).pack(side='left')

        body = tk.Frame(self, bg='white', padx=24, pady=14)
        body.pack(fill='both', expand=True)

        d = self.task_data
        today = datetime.date.today().strftime('%Y-%m-%d')

        self.v = {}
        fields = [
            ('TaskName',   'Task Name *',  d.get('TaskName', ''),   'entry'),
            ('Phase',      'Phase',        d.get('Phase', 'Executing'), 'phase'),
            ('AssignedTo', 'Assigned To',  d.get('AssignedTo', ''), 'entry'),
            ('StartDate',  'Start Date',   d.get('StartDate', today),'date'),
            ('EndDate',    'End Date',     d.get('EndDate', ''),    'date'),
            ('Status',     'Status',       d.get('Status', 'Not Started'), 'status'),
            ('Progress',   'Progress (0-100)', d.get('Progress', '0'), 'entry'),
            ('Notes',      'Notes',        d.get('Notes', ''),      'entry'),
        ]

        for i, (key, label, default, kind) in enumerate(fields):
            tk.Label(body, text=label,
                     font=('Segoe UI', 9, 'bold'),
                     bg='white', fg=C['ink'],
                     anchor='w').grid(row=i, column=0, sticky='w',
                                      pady=5, padx=(0, 16))
            v = tk.StringVar(value=str(default) if default else '')
            self.v[key] = v

            if kind == 'status':
                cb = ttk.Combobox(body, textvariable=v, width=30,
                                  values=self.STATUSES, state='readonly')
                cb.grid(row=i, column=1, sticky='ew', pady=5)
            elif kind == 'phase':
                cb = ttk.Combobox(body, textvariable=v, width=30,
                                  values=self.PHASES, state='readonly')
                cb.grid(row=i, column=1, sticky='ew', pady=5)
            elif kind == 'date':
                from ui.date_picker import DateEntry
                de = DateEntry(body, textvariable=v, width=22)
                de.grid(row=i, column=1, sticky='w', pady=5)
            else:
                tk.Entry(body, textvariable=v, width=33,
                         font=('Segoe UI', 9),
                         relief='solid', bd=1).grid(row=i, column=1,
                                                    sticky='ew', pady=5)

        # Hint
        tk.Label(body, text='Date format: YYYY-MM-DD',
                 font=('Segoe UI', 7), bg='white', fg=C['t2'],
                 anchor='w').grid(row=len(fields), column=0, columnspan=2,
                                  sticky='w', pady=(0, 4))

        # Colour preview label — updates as you type/select
        self._preview = tk.Label(body, text='',
                                 font=('Segoe UI', 8, 'bold'),
                                 padx=10, pady=4, anchor='w')
        self._preview.grid(row=len(fields)+1, column=0, columnspan=2,
                           sticky='ew', pady=(4, 0))
        self.v['Status'].trace_add('write', self._update_preview)
        self.v['EndDate'].trace_add('write', self._update_preview)
        self._update_preview()

        # Buttons
        btns = tk.Frame(self, bg='white', padx=24, pady=12)
        btns.pack(fill='x')
        tk.Button(btns, text='Save Task',
                  font=('Segoe UI', 10, 'bold'),
                  bg=C['accent'], fg='white',
                  activebackground='#3461f0', activeforeground='white',
                  relief='flat', bd=0, padx=18, pady=8,
                  cursor='hand2', command=self._save).pack(side='right', padx=(6, 0))
        tk.Button(btns, text='Cancel',
                  font=('Segoe UI', 10),
                  bg='#f0f2f7', fg=C['ink'],
                  relief='flat', bd=0, padx=18, pady=8,
                  cursor='hand2', command=self.destroy).pack(side='right')

    def _update_preview(self, *_):
        status  = self.v['Status'].get()
        end_d   = self.v['EndDate'].get()
        bg, fg, tag = task_row_color(status, '', end_d)
        labels  = {
            'completed':   'Row will appear: Completed (Green)',
            'overdue':     'Row will appear: OVERDUE — end date passed! (Red)',
            'at_risk':     'Row will appear: At Risk (Amber)',
            'in_prog':     'Row will appear: In Progress (Blue)',
            'on_hold':     'Row will appear: On Hold (Purple)',
            'not_started': 'Row will appear: Not Started (Grey)',
        }
        self._preview.config(text=labels.get(tag, ''), bg=bg, fg=fg)

    def _save(self):
        name = self.v['TaskName'].get().strip()
        if not name:
            messagebox.showwarning('Required', 'Task Name is required.', parent=self)
            return

        try:
            prog = float(self.v['Progress'].get() or '0')
            prog = max(0.0, min(100.0, prog))
        except:
            prog = 0.0

        data = {
            'ProjectID':   self.pid,
            'TaskID':      self.task_data.get('TaskID', ''),
            'TaskName':    name,
            'Phase':       self.v['Phase'].get(),
            'AssignedTo':  self.v['AssignedTo'].get().strip(),
            'StartDate':   self.v['StartDate'].get().strip(),
            'EndDate':     self.v['EndDate'].get().strip(),
            'Status':      self.v['Status'].get(),
            'Progress':    prog,
            'Notes':       self.v['Notes'].get().strip(),
            'ParentTaskID':self.task_data.get('ParentTaskID', ''),
        }

        try:
            self.svc.save_task(data)
        except Exception as e:
            messagebox.showerror('Save Failed',
                f'Could not save task:\n{e}', parent=self)
            return

        if self.on_save:
            self.on_save()
        self.destroy()
