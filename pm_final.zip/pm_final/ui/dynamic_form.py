import tkinter as tk
from tkinter import ttk
from tkcalendar import DateEntry


class DynamicForm(tk.Toplevel):

    def __init__(
        self,
        parent,
        columns,
        submit_callback,
        existing_data=None,
        sheet_name=None,
        data_service=None
    ):

        super().__init__(parent)

        self.title("Record Form")
        self.resizable(False, False)
        self.grab_set()          # modal — blocks clicks on parent window

        self.entries = {}
        self.submit_callback = submit_callback
        self.sheet_name  = sheet_name
        self.data_service = data_service

        for i, col in enumerate(columns):

            ttk.Label(self, text=col).grid(row=i, column=0, padx=10, pady=5, sticky="w")

            # ── ParentTask Dropdown ───────────────────────────────────────
            if col == "ParentTaskID" and self.sheet_name == "Tasks":

                entry = ttk.Combobox(self, state="readonly", width=28)

                if self.data_service:
                    tasks_df = self.data_service.get_sheet_data("Tasks")
                    options = ["None"]
                    for _, row in tasks_df.iterrows():
                        task_id = row.get("TaskID")
                        name    = row.get("TaskName")
                        if task_id and name:
                            try:
                                options.append(f"{int(task_id)} - {name}")
                            except:
                                pass
                    entry["values"] = options

                entry.grid(row=i, column=1, padx=10, pady=5)
                self.entries[col] = entry

                # pre-fill
                if existing_data is not None:
                    val = str(existing_data[i]).strip()
                    if val.lower() in ("", "none", "nan"):
                        entry.set("None")
                    else:
                        # find matching option
                        try:
                            pid = int(float(val))
                            match = next((o for o in entry["values"] if o.startswith(f"{pid} - ")), "None")
                            entry.set(match)
                        except:
                            entry.set("None")
                continue

            # ── Status Dropdown ───────────────────────────────────────────
            elif col.lower() == "status":
                entry = ttk.Combobox(
                    self,
                    values=["Not Started", "In Progress", "Completed", "Blocked"],
                    state="readonly",
                    width=28
                )
                entry.grid(row=i, column=1, padx=10, pady=5)
                self.entries[col] = entry
                if existing_data is not None:
                    val = str(existing_data[i]).strip()
                    entry.set(val if val not in ("", "nan", "None") else "Not Started")
                continue

            # ── AssignedTo Dropdown ───────────────────────────────────────
            elif col.lower() == "assignedto":
                entry = ttk.Combobox(
                    self,
                    values=["Kartikey", "Shayak", "Shasanka", "Sumit", "Maanik", "Ankita", "Jyotirmay", "Ritam"],
                    state="readonly",
                    width=28
                )
                entry.grid(row=i, column=1, padx=10, pady=5)
                self.entries[col] = entry
                if existing_data is not None:
                    val = str(existing_data[i]).strip()
                    entry.set(val if val not in ("", "nan", "None") else "")
                continue

            # ── Progress Dropdown ─────────────────────────────────────────
            elif col.lower() == "progress":
                entry = ttk.Combobox(
                    self,
                    values=[str(v) for v in range(0, 101, 10)],
                    state="readonly",
                    width=28
                )
                entry.grid(row=i, column=1, padx=10, pady=5)
                self.entries[col] = entry
                if existing_data is not None:
                    val = str(existing_data[i]).strip()
                    try:
                        # round to nearest 10 that exists in the list
                        pct = int(float(val))
                        rounded = str(round(pct / 10) * 10)
                        if rounded in [str(v) for v in range(0, 101, 10)]:
                            entry.set(rounded)
                        else:
                            entry.set("0")
                    except:
                        entry.set("0")
                continue

            # ── Date Picker ───────────────────────────────────────────────
            elif "date" in col.lower():
                entry = DateEntry(self, date_pattern="yyyy-mm-dd", width=26)
                entry.grid(row=i, column=1, padx=10, pady=5)
                self.entries[col] = entry
                if existing_data is not None:
                    val = str(existing_data[i]).strip()
                    if val not in ("", "nan", "None", "NaT"):
                        try:
                            entry.set_date(val[:10])
                        except:
                            pass
                continue

            # ── Default text entry ────────────────────────────────────────
            else:
                entry = ttk.Entry(self, width=30)
                entry.grid(row=i, column=1, padx=10, pady=5)
                self.entries[col] = entry
                if existing_data is not None:
                    val = str(existing_data[i]).strip()
                    if val.lower() not in ("nan", "none"):
                        entry.delete(0, "end")
                        entry.insert(0, val)
                continue

        ttk.Button(
            self,
            text="Save",
            command=self.submit
        ).grid(row=len(columns), column=0, columnspan=2, pady=14)

    # ==============================
    # SUBMIT
    # ==============================
    def submit(self):

        data = {}

        for col, entry in self.entries.items():
            value = entry.get()

            # ParentTaskID: extract int from "15 - TaskName" or "None"
            if col == "ParentTaskID":
                if not value or value.strip().lower() in ("none", "", "nan"):
                    value = None
                else:
                    try:
                        value = int(value.split(" - ")[0])
                    except:
                        value = None

            # Progress: always a float
            elif col.lower() == "progress":
                try:
                    value = float(value)
                except:
                    value = 0.0

            data[col] = value

        # Prevent self-parent
        if self.sheet_name == "Tasks":
            parent_id = data.get("ParentTaskID")
            task_id   = data.get("TaskID")
            if parent_id and task_id and str(parent_id) == str(task_id):
                print("❌ Task cannot be its own parent")
                return

        self.submit_callback(data)
        self.destroy()