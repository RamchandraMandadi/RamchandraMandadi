"""
portfolio_view.py  — Portfolio tab
Project cards with RAG filter bar, budget bar, edit/delete buttons.
"""
import tkinter as tk
from tkinter import ttk, messagebox
import datetime

C = {
    'bg':      '#f0f2f7', 'surface': '#ffffff', 'border':  '#dde1ed',
    'ink':     '#000000', 'ink2':    '#000000', 't2':      '#000000',
    't3':      '#000000', 'accent':  '#2952e3', 'accent2': '#2952e3',
    'R':       '#e53935', 'R_bg':    '#fdecea',
    'A':       '#f59e0b', 'A_bg':    '#fffbeb',
    'G':       '#16a34a', 'G_bg':    '#f0fdf4',
}
RAG_ASPECTS = ['Scope','Schedule','Budget','Changes','Issues',
               'Risks','Dependencies','Resourcing','Technical','Change Mgmt']
PRI_COLORS  = {'Critical':'#e53935','High':'#f59e0b',
               'Medium':'#3b82f6','Low':'#6b7280'}


def rag_color(s):
    return {'R':C['R'],'A':C['A'],'G':C['G']}.get(s, C['G'])

def pri_color(p):
    return PRI_COLORS.get(str(p).strip(), '#6b7280')

def _safe_float(v):
    try:
        f = float(v); return 0.0 if f != f else f
    except:
        return 0.0

def _overall_rag(p_rag):
    ss = [v.get('status','G') for v in p_rag.values()]
    return 'R' if 'R' in ss else ('A' if 'A' in ss else 'G')


class PortfolioView(tk.Frame):

    def __init__(self, parent, svc, on_open_detail=None):
        super().__init__(parent, bg=C['bg'])
        self.svc            = svc
        self.on_open_detail = on_open_detail
        self._filter        = 'All'   # All | R | A | G
        self._build()

    # ──────────────────────────────────────────────────────────────────────────
    def _build(self):
        # ── scrollable canvas ─────────────────────────────────────────────────
        self._canvas = tk.Canvas(self, bg=C['bg'], highlightthickness=0)
        vsb = ttk.Scrollbar(self, orient='vertical', command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._canvas.pack(side='left', fill='both', expand=True)

        self._inner  = tk.Frame(self._canvas, bg=C['bg'])
        self._win_id = self._canvas.create_window((0,0), window=self._inner, anchor='nw')

        self._inner.bind('<Configure>',
            lambda e: self._canvas.configure(scrollregion=self._canvas.bbox('all')))
        self._canvas.bind('<Configure>',
            lambda e: self._canvas.itemconfig(self._win_id, width=e.width))
        self._canvas.bind_all('<MouseWheel>',
            lambda e: self._canvas.yview_scroll(int(-1*(e.delta/60)),'units'))

        self._pad = tk.Frame(self._inner, bg=C['bg'], padx=22, pady=20)
        self._pad.pack(fill='both', expand=True)

        self._render()

    def _render(self):
        for w in self._pad.winfo_children():
            w.destroy()

        projects = self.svc.get_projects()
        rag_all  = self.svc.get_rag()
        status   = {str(s['ProjectID']): s for s in self.svc.get_status()}
        tasks_all= {str(p['ProjectID']): self.svc.get_tasks(str(p['ProjectID']))
                    for p in projects}

        # ── Page header ───────────────────────────────────────────────────────
        hdr = tk.Frame(self._pad, bg=C['bg'])
        hdr.pack(fill='x', pady=(0, 4))
        tk.Label(hdr, text='All Projects',
                 font=('Segoe UI', 16, 'bold'),
                 bg=C['bg'], fg=C['ink']).pack(side='left')

        tk.Label(self._pad,
                 text='Click any project card to view details, update RAG status and schedule',
                 font=('Segoe UI', 9), bg=C['bg'], fg=C['t2'],
                 anchor='w').pack(fill='x', pady=(0, 14))

        # ── Filter bar ────────────────────────────────────────────────────────
        fbar = tk.Frame(self._pad, bg=C['bg'])
        fbar.pack(fill='x', pady=(0, 18))

        filters = [
            ('All',   'All',   '#000000', 'white'),
            ('R',     '🔴 Red',   C['R'],    'white'),
            ('A',     '🟡 Amber', C['A'],    'white'),
            ('G',     '🟢 Green', C['G'],    'white'),
        ]
        self._filter_btns = {}
        for key, label, active_bg, active_fg in filters:
            is_active = (self._filter == key)
            btn = tk.Button(fbar, text=label,
                            font=('Segoe UI', 9, 'bold' if is_active else 'normal'),
                            bg=active_bg if is_active else '#e5e7eb',
                            fg=active_fg if is_active else C['ink'],
                            relief='flat', bd=0, padx=14, pady=6,
                            cursor='hand2',
                            command=lambda k=key: self._set_filter(k))
            btn.pack(side='left', padx=3)
            self._filter_btns[key] = btn

        # ── Card grid ─────────────────────────────────────────────────────────
        grid = tk.Frame(self._pad, bg=C['bg'])
        grid.pack(fill='both', expand=True)
        for col in range(3):
            grid.columnconfigure(col, weight=1)

        shown = 0
        for i, p in enumerate(projects):
            pid    = str(p['ProjectID'])
            p_rag  = rag_all.get(pid, {})
            overall= _overall_rag(p_rag)

            if self._filter != 'All' and overall != self._filter:
                continue

            p_stat  = status.get(pid, {})
            p_tasks = tasks_all.get(pid, [])
            self._project_card(grid, p, p_rag, p_stat, p_tasks,
                               row=shown//3, col=shown%3)
            shown += 1

        if shown == 0:
            tk.Label(grid, text='No projects match the selected filter.',
                     font=('Segoe UI', 11), bg=C['bg'], fg=C['t2'],
                     pady=40).grid(row=0, column=0, columnspan=3)

    def _set_filter(self, key):
        self._filter = key
        self._render()

    # ── Project card ──────────────────────────────────────────────────────────
    def _project_card(self, parent, p, p_rag, p_stat, tasks, row, col):
        pid     = str(p['ProjectID'])
        overall = _overall_rag(p_rag)

        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'],
                        highlightthickness=1)
        card.grid(row=row, column=col, sticky='nsew', padx=6, pady=6)

        # coloured top bar
        tk.Frame(card, bg=rag_color(overall), height=4).pack(fill='x')

        # ── card header ───────────────────────────────────────────────────────
        top = tk.Frame(card, bg=C['surface'])
        top.pack(fill='x', padx=14, pady=(10,6))

        badge = tk.Label(top, text=overall, width=2,
                         bg=rag_color(overall), fg='white',
                         font=('Segoe UI', 9, 'bold'), pady=2)
        badge.pack(side='left', padx=(0,8))

        name_frame = tk.Frame(top, bg=C['surface'])
        name_frame.pack(side='left', fill='x', expand=True)
        tk.Label(name_frame, text=p.get('ProjectName',''),
                 font=('Segoe UI', 10, 'bold'),
                 bg=C['surface'], fg=C['ink'], anchor='w').pack(fill='x')
        tk.Label(name_frame,
                 text=f"{p.get('Manager','')}  ·  {p.get('Client','')}",
                 font=('Segoe UI', 8), bg=C['surface'],
                 fg=C['t2'], anchor='w').pack(fill='x')

        pri = p.get('Priority','')
        if pri:
            tk.Label(top, text=pri,
                     bg=pri_color(pri), fg='white',
                     font=('Segoe UI', 7, 'bold'), padx=6, pady=2
                     ).pack(side='right')

        # priority · dates subtitle
        tk.Label(card,
                 text=f"  {pri_color_label(pri, p)}  ·  {p.get('StartDate','')}  →  {p.get('EndDate','')}",
                 font=('Segoe UI', 8), bg=C['surface'],
                 fg=PRI_COLORS.get(pri,'#6b7280'), anchor='w').pack(fill='x', padx=14)

        tk.Frame(card, bg=C['border'], height=1).pack(fill='x', padx=14, pady=4)

        # ── RAG mini grid ─────────────────────────────────────────────────────
        tk.Label(card, text='RAG by Aspect',
                 font=('Segoe UI', 7, 'bold'), bg=C['surface'],
                 fg=C['t2'], anchor='w').pack(fill='x', padx=14, pady=(4,2))

        rag_frame = tk.Frame(card, bg=C['surface'])
        rag_frame.pack(fill='x', padx=14, pady=(0,6))
        for ci in range(5):
            rag_frame.columnconfigure(ci, weight=1)
        for i, asp in enumerate(RAG_ASPECTS):
            s    = p_rag.get(asp, {}).get('status', 'G')
            cell = tk.Frame(rag_frame, bg=C['surface'])
            cell.grid(row=i//5, column=i%5, padx=2, pady=2, sticky='ew')
            tk.Label(cell, text=s, width=2,
                     bg=rag_color(s), fg='white',
                     font=('Segoe UI', 7, 'bold'), pady=2).pack()
            tk.Label(cell, text=asp[:6],
                     font=('Segoe UI', 6), bg=C['surface'], fg=C['t3']).pack()

        tk.Frame(card, bg=C['border'], height=1).pack(fill='x', padx=14, pady=4)

        # ── Budget spent bar ──────────────────────────────────────────────────
        budget    = _safe_float(p.get('Budget',0))
        spent     = _safe_float(p.get('Spent',0))
        spent_pct = (spent/budget*100) if budget else 0

        brow = tk.Frame(card, bg=C['surface'])
        brow.pack(fill='x', padx=14, pady=(2,2))
        tk.Label(brow, text='Budget Spent',
                 font=('Segoe UI', 8), bg=C['surface'], fg=C['t2'],
                 anchor='w').pack(side='left')
        tk.Label(brow, text=f'{spent_pct:.0f}%',
                 font=('Segoe UI', 8, 'bold'), bg=C['surface'],
                 fg=C['ink2']).pack(side='right')

        btrack = tk.Canvas(card, height=6, bg='#e5e7eb', highlightthickness=0)
        btrack.pack(fill='x', padx=14)
        def _draw_budget(e, sp=spent_pct, c=btrack):
            w = c.winfo_width()
            c.delete('all')
            c.create_rectangle(0,0,w,6,fill='#e5e7eb',outline='')
            fw = int(w * min(sp,100) / 100)
            if fw > 0:
                clr = C['R'] if sp > 90 else (C['A'] if sp > 70 else C['G'])
                c.create_rectangle(0,0,fw,6,fill=clr,outline='')
        btrack.bind('<Configure>', _draw_budget)

        tk.Label(card,
                 text=f'  ${spent:,.0f} spent                    ${budget:,.0f} total',
                 font=('Segoe UI', 7), bg=C['surface'], fg=C['t3'],
                 anchor='w').pack(fill='x', padx=14, pady=(2,6))

        # ── Footer: task count + edit/delete ──────────────────────────────────
        footer = tk.Frame(card, bg=C['surface'])
        footer.pack(fill='x', padx=14, pady=(0,10))

        n_tasks   = len(tasks)
        updated   = str(p.get('LastUpdated',''))[:10]
        tk.Label(footer,
                 text=f'📋 {n_tasks} task{"s" if n_tasks!=1 else ""}  ·  Updated {updated}',
                 font=('Segoe UI', 7), bg=C['surface'], fg=C['t3'],
                 anchor='w').pack(side='left')

        # ── Edit button ───────────────────────────────────────────────────────
        def _edit(pid=pid, p=p):
            proj = self.svc.get_project(pid)
            dlg  = _EditProjectDialog(self.winfo_toplevel(), self.svc, proj)
            # wait_window on toplevel, not on canvas child
            self.winfo_toplevel().wait_window(dlg)
            if getattr(dlg, 'saved', False):
                self.refresh()

        # ── Delete button ─────────────────────────────────────────────────────
        def _delete(pid=pid, pname=p.get('ProjectName','')):
            if messagebox.askyesno('Delete Project',
                    f'Delete "{pname}" and all its tasks?\nThis cannot be undone.',
                    parent=self.winfo_toplevel()):
                self.svc.delete_project(pid)
                self.refresh()

        tk.Button(footer, text='🗑', font=('Segoe UI', 11),
                  bg=C['surface'], fg='#e53935',
                  relief='flat', bd=0, cursor='hand2',
                  activebackground='#fdecea',
                  command=_delete).pack(side='right', padx=(4,0))

        tk.Button(footer, text='✏', font=('Segoe UI', 11),
                  bg=C['surface'], fg='#2952e3',
                  relief='flat', bd=0, cursor='hand2',
                  activebackground='#e8ecfa',
                  command=_edit).pack(side='right')

        # double-click anywhere on card to open detail (excludes edit/delete buttons)
        _exclude = {btrack}   # canvas widget — has its own Configure binding
        def _open(e, pid=pid):
            self.on_open_detail and self.on_open_detail(pid)

        def _bind_tree(widget):
            if widget not in _exclude and not isinstance(widget, tk.Button):
                widget.bind('<Double-Button-1>', _open)
            for child in widget.winfo_children():
                _bind_tree(child)

        _bind_tree(card)

    def refresh(self):
        self._render()


def pri_color_label(pri, p):
    return pri if pri else ''


# ══════════════════════════════════════════════════════════════════════════════
#  EDIT PROJECT DIALOG
# ══════════════════════════════════════════════════════════════════════════════
class _EditProjectDialog(tk.Toplevel):

    def __init__(self, parent, svc, project_data):
        super().__init__(parent)
        self.svc   = svc
        self.data  = project_data
        self.saved = False
        self.title('Edit Project')
        self.configure(bg='white')
        self.resizable(True, True)
        self.grab_set()
        self._build()
        self.update_idletasks()
        self.geometry('600x580')
        x = parent.winfo_rootx() + parent.winfo_width()  // 2 - 300
        y = max(parent.winfo_rooty() + 60, 30)
        self.geometry(f'+{x}+{y}')

    def _build(self):
        from ui.date_picker import DateEntry

        d = self.data
        def _clean(v):
            if v is None: return ''
            s = str(v).strip()
            return '' if s.lower() in ('nan','none','nat') else s

        # header
        hdr = tk.Frame(self, bg='#000000', height=50)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text=f"  ✏  Edit Project — {_clean(d.get('ProjectName',''))}",
                 font=('Segoe UI', 11, 'bold'),
                 bg='#000000', fg='white', pady=13).pack(side='left')

        body = tk.Frame(self, bg='white', padx=28, pady=16)
        body.pack(fill='both', expand=True)
        body.columnconfigure(1, weight=1)

        today = datetime.date.today().strftime('%Y-%m-%d')
        self.vars = {}
        fields = [
            ('ProjectID',   'Project ID',    _clean(d.get('ProjectID','')),       False),
            ('ProjectName', 'Project Name *',_clean(d.get('ProjectName','')),     True),
            ('Manager',     'Manager *',     _clean(d.get('Manager','')),         True),
            ('Client',      'Client',        _clean(d.get('Client','')),          True),
            ('Department',  'Department',    _clean(d.get('Department','')),      True),
            ('Priority',    'Priority',      _clean(d.get('Priority','High')),    True),
            ('StartDate',   'Start Date',    _clean(d.get('StartDate', today)),   True),
            ('EndDate',     'End Date',      _clean(d.get('EndDate','')),         True),
            ('Budget',      'Budget ($)',    _clean(d.get('Budget','')),          True),
            ('Spent',       'Spent ($)',     _clean(d.get('Spent','')),           True),
            ('Description', 'Description',  _clean(d.get('Description','')),     True),
        ]
        for i, (key, label, default, editable) in enumerate(fields):
            tk.Label(body, text=label, font=('Segoe UI', 9, 'bold'),
                     bg='white', fg='#000000', anchor='w').grid(
                row=i, column=0, sticky='w', pady=5, padx=(0,16))
            v = tk.StringVar(value=default)
            self.vars[key] = v

            if not editable:
                tk.Label(body, textvariable=v, font=('Segoe UI', 9),
                         bg='#f0f2f7', fg='#000000',
                         anchor='w', padx=6).grid(row=i, column=1, sticky='ew', pady=5)
            elif key == 'Priority':
                w = ttk.Combobox(body, textvariable=v,
                                 values=['Critical','High','Medium','Low'],
                                 state='readonly')
                w.grid(row=i, column=1, sticky='ew', pady=5)
            elif key in ('StartDate', 'EndDate'):
                w = DateEntry(body, textvariable=v, width=18)
                w.grid(row=i, column=1, sticky='w', pady=5)
            else:
                w = tk.Entry(body, textvariable=v, font=('Segoe UI', 9),
                             relief='solid', bd=1)
                w.grid(row=i, column=1, sticky='ew', pady=5)

        # footer
        foot = tk.Frame(self, bg='white', pady=12, padx=28)
        foot.pack(fill='x')
        tk.Button(foot, text='Save Changes',
                  font=('Segoe UI', 10, 'bold'),
                  bg='#2952e3', fg='white',
                  activebackground='#3461f0', activeforeground='white',
                  relief='flat', bd=0, padx=20, pady=9,
                  cursor='hand2', command=self._save).pack(side='right', padx=(8,0))
        tk.Button(foot, text='Cancel',
                  font=('Segoe UI', 10), bg='#f0f2f7', fg='#000000',
                  relief='flat', bd=0, padx=20, pady=9,
                  cursor='hand2', command=self.destroy).pack(side='right')

    def _save(self):
        data = {k: v.get().strip() for k, v in self.vars.items()}
        if not data.get('ProjectName') or not data.get('Manager'):
            messagebox.showwarning('Required',
                'Project Name and Manager are required.', parent=self)
            return
        data['LastUpdated'] = datetime.date.today().strftime('%Y-%m-%d')
        try:
            self.svc.save_project(data)
            self.saved = True
            self.destroy()
        except Exception as e:
            messagebox.showerror('Save Error', str(e), parent=self)
