"""
portfolio_service.py
Reads Projects, RAG, Tasks, ProjectStatus from Excel.
"""
import pandas as pd
from config.settings import Settings

RAG_ASPECTS = ['Scope','Schedule','Budget','Changes','Issues',
               'Risks','Dependencies','Resourcing','Technical','Change Mgmt']

class PortfolioService:

    def __init__(self):
        self.path = Settings.EXCEL_FILE

    def _read(self, sheet):
        try:
            return pd.read_excel(self.path, sheet_name=sheet)
        except Exception as e:
            print(f"Error reading {sheet}: {e}")
            return pd.DataFrame()

    # ── Projects ──────────────────────────────────────────────────────────────
    def get_projects(self):
        return self._read('Projects').to_dict('records')

    def get_project(self, pid):
        df = self._read('Projects')
        rows = df[df['ProjectID'].astype(str) == str(pid)]
        return rows.iloc[0].to_dict() if not rows.empty else {}

    # ── RAG ───────────────────────────────────────────────────────────────────
    def get_rag(self):
        """Returns {project_id: {aspect: {status, explanation}}}"""
        df = self._read('RAG')

        def _clean(v):
            """Convert pandas NaN / None / 'nan' to empty string."""
            if v is None:
                return ''
            if isinstance(v, float):          # catches float('nan')
                return ''
            s = str(v).strip()
            return '' if s.lower() in ('nan', 'none', 'nat', 'null') else s

        result = {}
        for _, r in df.iterrows():
            pid = str(r.get('ProjectID', ''))
            asp = str(r.get('Aspect', ''))
            if pid not in result:
                result[pid] = {}
            result[pid][asp] = {
                'status':      _clean(r.get('Status')) or 'G',
                'explanation': _clean(r.get('Explanation')),
            }
        return result

    def get_project_rag(self, pid):
        rag = self.get_rag()
        return rag.get(str(pid), {})

    def get_overall_rag(self, pid):
        """Worst of: R > A > G"""
        rag = self.get_project_rag(pid)
        statuses = [v['status'] for v in rag.values()]
        if 'R' in statuses: return 'R'
        if 'A' in statuses: return 'A'
        return 'G'

    # ── Tasks ─────────────────────────────────────────────────────────────────
    def get_tasks(self, pid=None):
        df = self._read('Tasks')
        if pid:
            df = df[df['ProjectID'].astype(str) == str(pid)]
        return df.to_dict('records')

    # ── ProjectStatus ─────────────────────────────────────────────────────────
    def get_status(self):
        return self._read('ProjectStatus').to_dict('records')

    # ── Dashboard KPIs ────────────────────────────────────────────────────────
    def get_kpis(self):
        projects = self.get_projects()
        rag      = self.get_rag()
        status   = {s['ProjectID']: s for s in self.get_status()}

        total   = len(projects)
        at_risk = sum(1 for p in projects
                      if self.get_overall_rag(p['ProjectID']) == 'R')
        amber   = sum(1 for p in projects
                      if self.get_overall_rag(p['ProjectID']) == 'A')

        total_budget = sum(float(p.get('Budget', 0) or 0) for p in projects)
        total_spent  = sum(float(p.get('Spent',  0) or 0) for p in projects)

        progress_vals = [float(s.get('Progress', 0) or 0) for s in status.values()]
        avg_progress  = (sum(progress_vals) / len(progress_vals)) if progress_vals else 0

        return {
            'total':        total,
            'at_risk':      at_risk,
            'amber':        amber,
            'green':        total - at_risk - amber,
            'budget':       total_budget,
            'spent':        total_spent,
            'avg_progress': round(avg_progress, 1),
        }

    # ── RAG aspect summary (for bar chart) ───────────────────────────────────
    def get_rag_summary(self):
        """Returns {aspect: {R: n, A: n, G: n}} across all projects"""
        rag = self.get_rag()
        summary = {asp: {'R': 0, 'A': 0, 'G': 0} for asp in RAG_ASPECTS}
        for pid_data in rag.values():
            for asp in RAG_ASPECTS:
                s = pid_data.get(asp, {}).get('status', 'G')
                if s in ('R', 'A', 'G'):
                    summary[asp][s] += 1
        return summary

    # ── Projects at risk ─────────────────────────────────────────────────────
    def get_projects_at_risk(self):
        projects = self.get_projects()
        rag      = self.get_rag()
        result   = []
        for p in projects:
            pid = str(p['ProjectID'])
            p_rag = rag.get(pid, {})
            reds  = [a for a in RAG_ASPECTS if p_rag.get(a, {}).get('status') == 'R']
            if reds:
                result.append({
                    'id':      pid,
                    'name':    p.get('ProjectName', ''),
                    'manager': p.get('Manager', ''),
                    'reds':    reds,
                    'overall': self.get_overall_rag(pid),
                })
        return result

    # ── Portfolio health table ────────────────────────────────────────────────
    def get_health_table(self):
        projects = self.get_projects()
        rag      = self.get_rag()
        rows = []
        for p in projects:
            pid   = str(p['ProjectID'])
            p_rag = rag.get(pid, {})
            row = {
                'name':    p.get('ProjectName', ''),
                'manager': p.get('Manager', ''),
                'overall': self.get_overall_rag(pid),
            }
            for asp in RAG_ASPECTS:
                row[asp] = p_rag.get(asp, {}).get('status', 'G')
            rows.append(row)
        return rows

    # ── Write ─────────────────────────────────────────────────────────────────
    def save_project(self, data):
        df  = self._read('Projects')
        pid = str(data.get('ProjectID', '')).strip()
        mask   = df['ProjectID'].astype(str).str.strip() == pid
        is_new = not mask.any()
        cols   = list(df.columns)

        if mask.any():
            # Dict-based update — avoids all pandas dtype conflicts
            records = df.to_dict('records')
            for rec in records:
                if str(rec.get('ProjectID','')).strip() == pid:
                    for k, v in data.items():
                        if k in cols:
                            rec[k] = v
                    break
            self._write('Projects', pd.DataFrame(records))
        else:
            new_row = {col: data.get(col, '') for col in cols}
            new_row.update(data)
            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
            self._write('Projects', df)

        # Auto-create RAG rows (all Green) for brand-new projects
        if is_new:
            self._init_project_rag(pid)

    def _init_project_rag(self, pid):
        """Insert 10 default Green RAG rows for a new project."""
        df  = self._read('RAG')
        existing = df['ProjectID'].astype(str).str.strip().values
        if pid not in existing:
            new_rows = [
                {'ProjectID': pid, 'Aspect': asp, 'Status': 'G', 'Explanation': ''}
                for asp in RAG_ASPECTS
            ]
            df = pd.concat([df, pd.DataFrame(new_rows)], ignore_index=True)
            self._write('RAG', df)

    def _write(self, sheet, df):
        with pd.ExcelWriter(self.path, engine='openpyxl',
                            mode='a', if_sheet_exists='replace') as w:
            df.to_excel(w, sheet_name=sheet, index=False)

    # ── Task CRUD ─────────────────────────────────────────────────────────────
    def save_task(self, task_data):
        """Add or update a task. Uses dict-based update to avoid pandas dtype issues."""
        df  = self._read('Tasks')
        tid = str(task_data.get('TaskID', '')).strip()
        pid = str(task_data.get('ProjectID', '')).strip()

        # ── Normalise ID: handles 't4', '4', '4.0', 4  all the same ─────────
        def _norm_id(v):
            s = str(v).strip()
            # strip leading 't' prefix if present
            core = s.lower().lstrip('t') if s.lower().startswith('t') else s
            try:
                return str(int(float(core)))
            except:
                return s.lower()

        # ── Generate a new ID if this is a new task ───────────────────────────
        if not tid or tid.lower() in ('', 'nan', 'none'):
            max_n = 0
            for v in df['TaskID'].astype(str).values:
                core = str(v).strip().lower()
                core = core.lstrip('t') if core.startswith('t') else core
                try:
                    max_n = max(max_n, int(float(core)))
                except:
                    pass
            task_data['TaskID'] = f't{max_n + 1}'
            tid = task_data['TaskID']

        norm_tid = _norm_id(tid)

        # ── Update via dict records — no pandas dtype conflicts ───────────────
        records  = df.to_dict('records')
        cols     = list(df.columns)
        found    = False

        for rec in records:
            rec_pid = str(rec.get('ProjectID', '')).strip()
            rec_tid = _norm_id(rec.get('TaskID', ''))
            if rec_tid == norm_tid and rec_pid == pid:
                for k, v in task_data.items():
                    if k in cols:
                        rec[k] = v
                found = True
                break

        if not found:
            new_row = {col: task_data.get(col, '') for col in cols}
            records.append(new_row)

        self._write('Tasks', pd.DataFrame(records))

    def delete_task(self, task_id, pid):
        """Delete a task from the Tasks sheet."""
        def _norm_id(v):
            s = str(v).strip()
            core = s.lower().lstrip('t') if s.lower().startswith('t') else s
            try:
                return str(int(float(core)))
            except:
                return s.lower()

        df       = self._read('Tasks')
        norm_tid = _norm_id(task_id)
        pid      = str(pid).strip()
        records  = [
            r for r in df.to_dict('records')
            if not (_norm_id(r.get('TaskID', '')) == norm_tid and
                    str(r.get('ProjectID', '')).strip() == pid)
        ]
        self._write('Tasks', pd.DataFrame(records))

    def get_task_columns(self):
        df = self._read('Tasks')
        return list(df.columns)

    # ── Timeline data ─────────────────────────────────────────────────────────
    def get_hierarchy_ordered_tasks(self):
        """Returns flat list for TimelineView: project headers + tasks."""
        projects = self.get_projects()
        ordered  = []
        for p in projects:
            pid = str(p['ProjectID'])
            ordered.append({
                'TaskName':   p.get('ProjectName', ''),
                'ProjectName':p.get('ProjectName', ''),
                'level':      0,
                'is_project': True,
                'ProjectID':  pid,
            })
            for t in self.get_tasks(pid):
                row = dict(t)
                row['level']       = 1
                row['is_project']  = False
                row['ProjectName'] = p.get('ProjectName', '')
                ordered.append(row)
        return ordered

    def update_task_dates(self, task_id, project_id, start_date, end_date):
        """Update StartDate / EndDate of a task (used by timeline drag-drop)."""
        df   = self._read('Tasks')
        mask = (df['TaskID'].astype(str)   == str(task_id)) & \
               (df['ProjectID'].astype(str) == str(project_id))
        if mask.any():
            df.loc[mask, 'StartDate'] = start_date
            df.loc[mask, 'EndDate']   = end_date
            self._write('Tasks', df)

    # ── ProjectStatus calculation ─────────────────────────────────────────────
    def compute_project_status(self, pid):
        """
        Green  — ALL tasks completed before/on the project end date
        Red    — project end date has PASSED and any task is NOT complete
        Amber  — project has started but end date not yet passed
        """
        import datetime
        def _parse(v):
            if not v or str(v).strip().lower() in ('','nan','nat','none'):
                return None
            for fmt in ('%Y-%m-%d','%d/%m/%Y','%m/%d/%Y'):
                try:
                    return datetime.datetime.strptime(str(v)[:10], fmt).date()
                except:
                    pass
            return None

        today    = datetime.date.today()
        project  = self.get_project(pid)
        end_dt   = _parse(project.get('EndDate'))
        start_dt = _parse(project.get('StartDate'))
        tasks    = self.get_tasks(pid)

        if not tasks:
            return 'G'

        def _is_done(t):
            try:
                if float(t.get('Progress', 0) or 0) >= 100:
                    return True
            except:
                pass
            return str(t.get('Status', '')).strip() == 'Completed'

        all_done = all(_is_done(t) for t in tasks)

        if all_done:
            return 'G'                         # all tasks complete → Green
        if end_dt and end_dt < today:
            return 'R'                         # past end date, not all done → Red
        if start_dt and start_dt <= today:
            return 'A'                         # in progress → Amber
        return 'G'                             # not yet started → Green

    def refresh_all_statuses(self):
        """Recompute AutoStatus for every project and write to ProjectStatus sheet."""
        import datetime
        projects  = self.get_projects()
        now       = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        rows = []
        for p in projects:
            pid    = str(p['ProjectID'])
            status = self.compute_project_status(pid)
            tasks  = self.get_tasks(pid)
            prog_vals = []
            for t in tasks:
                try:
                    prog_vals.append(float(t.get('Progress', 0) or 0))
                except:
                    pass
            avg_prog = round((sum(prog_vals) / len(prog_vals)) if prog_vals else 0.0, 1)
            rows.append({
                'ProjectID':   pid,
                'ProjectName': p.get('ProjectName', ''),
                'Progress':    avg_prog,
                'AutoStatus':  {'R':'Red','A':'Amber','G':'Green'}[status],
                'StartDate':   str(p.get('StartDate', '')),
                'EndDate':     str(p.get('EndDate', '')),
                'LastUpdated': now,
                'Comment':     '',
            })
        new_df = pd.DataFrame(rows)
        self._write('ProjectStatus', new_df)

    # ── Repo adapter (needed by TimelineView drag-drop) ───────────────────────
    @property
    def repo(self):
        return _RepoAdapter(self)



    # ── RAG edit ──────────────────────────────────────────────────────────────
    def save_rag_entry(self, pid, aspect, status, explanation):
        """Update a single RAG row in Excel and return True on success."""
        df = self._read('RAG')
        mask = (df['ProjectID'].astype(str) == str(pid)) & \
               (df['Aspect'].astype(str) == str(aspect))
        if mask.any():
            df.loc[mask, 'Status']      = status
            df.loc[mask, 'Explanation'] = explanation
        else:
            new_row = {'ProjectID': pid, 'Aspect': aspect,
                       'Status': status, 'Explanation': explanation}
            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        self._write('RAG', df)
        return True

    # ── Project edit / delete ─────────────────────────────────────────────────
    def delete_project(self, pid):
        """Remove project + its RAG rows + its tasks from Excel."""
        pid = str(pid).strip()
        for sheet in ('Projects', 'RAG', 'Tasks', 'ProjectStatus'):
            try:
                df = self._read(sheet)
                df = df[df['ProjectID'].astype(str).str.strip() != pid]
                self._write(sheet, df)
            except Exception as e:
                print(f'Warning deleting {sheet}: {e}')

class _RepoAdapter:
    """Thin adapter so TimelineView can call svc.repo.update_row_by_id(...)."""
    def __init__(self, svc):
        self._svc = svc

    def update_row_by_id(self, sheet, key_col, key_val, data):
        if sheet == 'Tasks':
            pid = data.get('ProjectID', '')
            self._svc.update_task_dates(
                key_val, pid,
                data.get('StartDate', ''),
                data.get('EndDate', ''),
            )
