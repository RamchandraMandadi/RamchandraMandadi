import pandas as pd


class ProgressService:

    # ==============================
    # 🚀 CALCULATE TASK PROGRESS (RECURSIVE)
    # ==============================
    def calculate_task_progress(self, tasks):

        # ==============================
        # STEP 1: Normalize IDs
        # ==============================
        task_map = {}
        children_map = {}

        for t in tasks:

            # Normalize TaskID
            try:
                task_id = int(float(t.get("TaskID")))
            except:
                continue

            # Normalize ParentTaskID
            parent_raw = t.get("ParentTaskID")

            try:
                parent_id = int(float(parent_raw)) if parent_raw not in [None, "", "nan"] and not pd.isna(parent_raw) else None
            except:
                parent_id = None

            t["TaskID"] = task_id
            t["ParentTaskID"] = parent_id

            task_map[task_id] = t

            if parent_id is not None:
                children_map.setdefault(parent_id, []).append(task_id)

        # ==============================
        # STEP 2: Recursive calculation
        # ==============================
        def compute(task_id):

            task_id = int(task_id)
            task = task_map.get(task_id)

            if not task:
                return 0.0

            children = children_map.get(task_id, [])

            # ✅ Leaf node
            if not children:
                val = task.get("Progress")

                try:
                    return float(val)
                except:
                    return 0.0

            # ✅ Parent node → average of children
            child_values = [compute(child_id) for child_id in children]

            avg = sum(child_values) / len(child_values) if child_values else 0.0

            avg = round(avg, 2)

            task["Progress"] = avg

            return avg

        # ==============================
        # STEP 3: Run for root tasks
        # ==============================
        for t in tasks:

            parent = t.get("ParentTaskID")

            if parent is None:
                compute(t["TaskID"])

        return tasks

    # ==============================
    # 📊 PROJECT PROGRESS
    # ==============================
    def calculate_project_progress(self, tasks):

        root_tasks = [
            t for t in tasks
            if t.get("ParentTaskID") is None
        ]

        if not root_tasks:
            return 0.0

        values = []

        for t in root_tasks:
            try:
                values.append(float(t.get("Progress")))
            except:
                values.append(0.0)

        return round(sum(values) / len(values), 2)