import math


class TaskHierarchyBuilder:

    def safe_int(self, value):

        try:
            if value is None:
                return None

            # ✅ Handle real NaN
            if isinstance(value, float) and math.isnan(value):
                return None

            if str(value).strip().lower() in ["", "nan", "none"]:
                return None

            return int(float(value))

        except:
            return None

    def build_tree(self, tasks):

        task_map = {}
        roots = []
        cleaned_tasks = []

        # ==========================
        # STEP 1: CLEAN DATA
        # ==========================
        for task in tasks:

            task_id = self.safe_int(task.get("TaskID"))

            if task_id is None:
                continue

            parent_id = self.safe_int(task.get("ParentTaskID"))

            new_task = dict(task)

            new_task["TaskID"] = task_id
            new_task["ParentTaskID"] = parent_id
            new_task["children"] = []

            cleaned_tasks.append(new_task)
            task_map[task_id] = new_task

        # ==========================
        # STEP 2: BUILD TREE
        # ==========================
        for task in cleaned_tasks:

            parent_id = task["ParentTaskID"]

            if parent_id and parent_id in task_map:

                # Prevent self-parenting
                if parent_id == task["TaskID"]:
                    continue

                task_map[parent_id]["children"].append(task)

            else:
                roots.append(task)

        return roots