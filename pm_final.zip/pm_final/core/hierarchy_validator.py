import math


class HierarchyValidator:

    def safe_int(self, value):
        """
        Safely convert a value to int.
        Returns None for NaN, None, empty string, or unconvertible values.
        """
        try:
            if value is None:
                return None
            if isinstance(value, float) and math.isnan(value):
                return None
            if str(value).strip().lower() in ["", "nan", "none"]:
                return None
            return int(float(value))
        except:
            return None

    def validate(self, tasks):

        task_ids = set()

        for t in tasks:
            tid = self.safe_int(t.get("TaskID"))
            if tid is not None:
                task_ids.add(tid)

        for task in tasks:

            task_id = self.safe_int(task.get("TaskID"))
            if task_id is None:
                continue

            parent = self.safe_int(task.get("ParentTaskID"))

            if parent is not None:

                if parent == task_id:
                    raise ValueError("Task cannot be parent of itself")

                if parent not in task_ids:
                    raise ValueError(f"Invalid ParentTaskID {parent}")

        self.check_circular(tasks)

    def check_circular(self, tasks):

        parent_map = {}

        for t in tasks:
            tid = self.safe_int(t.get("TaskID"))
            pid = self.safe_int(t.get("ParentTaskID"))
            if tid is not None:
                parent_map[tid] = pid

        for task_id in parent_map:

            visited = set()
            current = task_id

            while True:
                parent = parent_map.get(current)
                if parent is None:
                    break
                if parent in visited:
                    raise ValueError("Circular hierarchy detected")
                visited.add(parent)
                current = parent