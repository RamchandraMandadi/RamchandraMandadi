from repository.excel_repository import ExcelRepository


class SchemaReader:

    def __init__(self):
        self.repo = ExcelRepository()

    def get_schema(self):
        """
        Returns schema for entire Excel workbook
        """

        schema = {}

        sheets = self.repo.get_all_sheets()

        for sheet in sheets:

            df = self.repo.read_sheet(sheet)

            columns = list(df.columns)

            column_types = {}

            for col in columns:

                column_types[col] = str(df[col].dtype)

            schema[sheet] = {
                "columns": columns,
                "types": column_types
            }

        return schema

    def get_sheet_schema(self, sheet_name):
        """
        Returns schema for one sheet
        """

        df = self.repo.read_sheet(sheet_name)

        columns = list(df.columns)

        column_types = {}

        for col in columns:
            column_types[col] = str(df[col].dtype)

        return {
            "sheet": sheet_name,
            "columns": columns,
            "types": column_types
        }