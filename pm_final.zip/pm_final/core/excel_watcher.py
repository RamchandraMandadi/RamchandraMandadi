from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from config.settings import Settings
import time
import threading


class ExcelChangeHandler(FileSystemEventHandler):

    def __init__(self, callback):
        self.callback = callback
        self._debounce_timer = None

    def on_modified(self, event):
        if event.src_path.endswith("project_data.xlsx"):

            # Cancel previous timer if fired again quickly
            if self._debounce_timer:
                self._debounce_timer.cancel()

            # Wait 500ms before triggering — Excel saves fire multiple events
            self._debounce_timer = threading.Timer(0.5, self.callback)
            self._debounce_timer.start()


class ExcelWatcher:

    def __init__(self, callback):

        self.callback = callback
        self.observer = Observer()

    def start(self):

        event_handler = ExcelChangeHandler(self.callback)

        self.observer.schedule(
            event_handler,
            path=str(Settings.INPUT_FOLDER),
            recursive=False
        )

        self.observer.start()

    def stop(self):

        self.observer.stop()
        self.observer.join()