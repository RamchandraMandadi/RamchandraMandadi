import pandas as pd
from config.settings import Settings


class ExcelRepository:

    def __init__(self):
        self.file_path = Settings.EXCEL_FILE

    # ==============================
    # SHEET OPERATIONS
    # ==============================
    def get_all_sheets(self):
        excel_file = pd.ExcelFile(self.file_path)
        return excel_file.sheet_names

    def read_sheet(self, sheet_name):
        try:
            df = pd.read_excel(self.file_path, sheet_name=sheet_name)
            return df
        except Exception as e:
            print(f"❌ Error reading sheet {sheet_name}: {e}")
            return pd.DataFrame()

    def get_columns(self, sheet_name):
        df = self.read_sheet(sheet_name)
        return list(df.columns)

    # ==============================
    # WRITE (FIXED - SINGLE METHOD)
    # ==============================
    def write_sheet(self, sheet_name, df):

        with pd.ExcelWriter(
            self.file_path,
            engine="openpyxl",
            mode="a",
            if_sheet_exists="replace"
        ) as writer:

            df.to_excel(writer, sheet_name=sheet_name, index=False)

    # ==============================
    # ADD
    # ==============================
    def append_row(self, sheet_name, row_data):

        df = self.read_sheet(sheet_name)

        new_df = pd.concat(
            [df, pd.DataFrame([row_data])],
            ignore_index=True
        )

        print("🔥 Writing new row:", row_data)

        self.write_sheet(sheet_name, new_df)

    # ==============================
    # UPDATE (PRIMARY KEY BASED)
    # ==============================
    def update_row_by_id(self, sheet_name, key_column, key_value, updated_data):

        df = self.read_sheet(sheet_name)

        if key_column not in df.columns:
            print(f"❌ Column {key_column} not found")
            return

        # Convert to string for safe comparison
        df[key_column] = df[key_column].astype(str)

        idx = df[df[key_column] == str(key_value)].index

        if len(idx) == 0:
            print("❌ Record not found")
            return

        print(f"🔥 Updating row where {key_column}={key_value}")

        for col, val in updated_data.items():
            if col not in df.columns:
                continue

            col_dtype = df[col].dtype

            try:
                if pd.api.types.is_integer_dtype(col_dtype):
                    val = pd.array([val], dtype="Int64")[0] if val not in ["", None, "nan"] else pd.NA
                elif pd.api.types.is_float_dtype(col_dtype):
                    val = float(val) if val not in ["", None, "nan"] else None
            except:
                pass

            df[col] = df[col].astype(object)
            df.loc[idx[0], col] = val

        self.write_sheet(sheet_name, df)

    # ==============================
    # DELETE
    # ==============================
    def delete_row(self, sheet_name, row_index):

        df = self.read_sheet(sheet_name)

        if row_index not in df.index:
            print("❌ Invalid row index")
            return

        print(f"🔥 Deleting row index: {row_index}")

        df = df.drop(index=row_index).reset_index(drop=True)

        self.write_sheet(sheet_name, df)